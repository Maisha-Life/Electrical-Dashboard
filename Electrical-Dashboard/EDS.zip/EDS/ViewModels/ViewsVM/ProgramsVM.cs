﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using EDS.Data;
using EDS.Models;
using EDS.Utilities;
using EDS.ViewModels.ModelsVM;
using MVVM.Utilities;

namespace EDS.ViewModels.ViewsVM
{
    public class ProgramsVM : BaseVM
    {
        public ScanData data;

        public ProgramsVM()
        {
            EDSData.grabData();

            Programs = EDSData.programs;

            GetStatistics();
        }

        #region Data Binds

        private ScanData _EDSData;
        public ScanData EDSData
        {
            get { return _EDSData ?? (_EDSData = new ScanData()); }
            set { this._EDSData = value; }
        }

        private ObservableCollection<vmProgram> _Programs;
        public ObservableCollection<vmProgram> Programs
        {
            get
            {
                if (_Programs == null)
                    _Programs = new ObservableCollection<vmProgram>();
                return _Programs;
            }
            set
            {
                if (this._Programs != value)
                {
                    this._Programs = value;
                    this.RaisePropertyChangedEvent("Programs");
                }
            }
        }

        private vmProgram _SelectedProgram;
        public vmProgram SelectedProgram
        {
            get { return _SelectedProgram; }
            set
            {
                if (this._SelectedProgram != value)
                {
                    this._SelectedProgram = value;
                    this.RaisePropertyChangedEvent("SelectedProgram");
                }
            }
        }

        private vmHarness _SelectedHarness;
        public vmHarness SelectedHarness
        {
            get { return _SelectedHarness; }
            set
            {
                if (this._SelectedHarness != value)
                {
                    this._SelectedHarness = value;
                    this.RaisePropertyChangedEvent("SelectedHarness");
                }
            }
        }

        private Visibility _HomeVisibility;
        public Visibility HomeVisibility
        {
            get { return _HomeVisibility; }
            set
            {
                if (this._HomeVisibility != value)
                {
                    this._HomeVisibility = value;
                    this.RaisePropertyChangedEvent("HomeVisibility");
                }
            }
        }

        private int _TotalCount;
        public int TotalCount
        {
            get { return _TotalCount; }
            set
            {
                if (this._TotalCount != value)
                {
                    this._TotalCount = value;
                    this.RaisePropertyChangedEvent("TotalCount");
                }
            }
        }

        private int _GoodCount;
        public int GoodCount
        {
            get { return _GoodCount; }
            set
            {
                if (this._GoodCount != value)
                {
                    this._GoodCount = value;
                    this.RaisePropertyChangedEvent("GoodCount");
                }
            }
        }

        private int _WarningCount;
        public int WarningCount
        {
            get { return _WarningCount; }
            set
            {
                if (this._WarningCount != value)
                {
                    this._WarningCount = value;
                    this.RaisePropertyChangedEvent("WarningCount");
                }
            }
        }

        private int _ErrorCount;
        public int ErrorCount
        {
            get { return _ErrorCount; }
            set
            {
                if (this._ErrorCount != value)
                {
                    this._ErrorCount = value;
                    this.RaisePropertyChangedEvent("ErrorCount");
                }
            }
        }

        #endregion

        #region Commands

        private RelayCommand _AddProgramCommand;
        public ICommand AddProgramCommand
        {
            get
            {
                if (_AddProgramCommand == null) _AddProgramCommand = new RelayCommand(param => addProgram(), param => { return (true); });

                return _AddProgramCommand;
            }
        }
        private void addProgram()
        {
            vmProgram program = new vmProgram(Program.CreateProgram(), Programs);

            PopupHelper.TabIndex(5, program);
            PopupHelper.SetVisibility(true);
        }


        #endregion

        #region Methods

        public void GetStatistics()
        {
            TotalCount = 0;
            GoodCount = 0;
            WarningCount = 0;
            ErrorCount = 0;

            foreach (vmProgram program in Programs)
            {
                program.GetStatistics();

                GoodCount += program.GoodCount;
                WarningCount += program.WarningCount;
                ErrorCount += program.ErrorCount;
            }

            TotalCount = GoodCount + WarningCount + ErrorCount;
        }

        public void basic()
        {
            EDSData.grabData();

            GetStatistics();

            //ruleList.Refresh();
        }

        #endregion
    }
}
