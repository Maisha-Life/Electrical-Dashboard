﻿using System;
using System.Windows.Input;
using EDS.Utilities;
using MVVM.Utilities;

namespace EDS.ViewModels.ViewsVM
{
    public class MainVM : BaseVM
    {
        public MainVM()
        {
            User = Environment.UserName;

            SelectedTabIndex = 1;
        }

        #region Data Binds

        private string _User;
        public string User
        {
            get { return _User; }
            set
            {
                if (this._User != value)
                {
                    this._User = value;
                    this.RaisePropertyChangedEvent("User");
                }
            }
        }

        private int _SelectedTabIndex;
        public int SelectedTabIndex
        {
            get { return _SelectedTabIndex; }
            set
            {
                if (this._SelectedTabIndex != value)
                {
                    this._SelectedTabIndex = value;
                    this.RaisePropertyChangedEvent("SelectedTabIndex");
                }
            }
        }
        
        #endregion

        #region Commands

        private RelayCommand _ToolBarToggle;
        public ICommand ToolBarToggle
        {
            get
            {
                if (_ToolBarToggle == null) _ToolBarToggle = new RelayCommand(param => toolBarToggle(), param => { return (true); });

                return _ToolBarToggle;
            }
        }
        private void toolBarToggle()
        {
            if (ToolBarHelper.VisibleBool == false)
            {
                ToolBarHelper.EDSToolBar = new Windows.EDSToolBar();
                ToolBarHelper.Show();
            }
            else
                ToolBarHelper.Close();
        }

        #endregion
    }
}
