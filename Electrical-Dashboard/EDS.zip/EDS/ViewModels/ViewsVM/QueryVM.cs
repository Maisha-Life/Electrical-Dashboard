﻿using MVVM.Utilities;
using SQLQueryVM;

using System.Collections.ObjectModel;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Windows.Input;

namespace EDS.ViewModels.ViewsVM
{
    public class vmQuery : vmBase
    {
        #region Constructor

        public vmQuery() { }

        #endregion

        #region Data Binds

        private ObservableCollection<vmQueryItem> _queries;
        public ObservableCollection<vmQueryItem> queries
        {
            get
            {
                if (_queries == null)
                    _queries = new ObservableCollection<vmQueryItem>();
                return _queries;
            }
            set
            {
                if (this._queries != value)
                {
                    this._queries = value;
                    this.RaisePropertyChangedEvent("queries");
                }
            }
        }

        private ObservableCollection<vmQueryItem> _queriesRule;
        public ObservableCollection<vmQueryItem> queriesRule
        {
            get
            {
                if (_queries == null)
                    _queries = new ObservableCollection<vmQueryItem>();
                return _queries;
            }
            set
            {
                if (this._queries != value)
                {
                    this._queries = value;
                    this.RaisePropertyChangedEvent("queriesRule");
                }
            }
        }

        #endregion

        #region Commands

        private RelayCommand _PushToDatabaseCommand;
        public ICommand PushToDatabaseCommand
        {
            get
            {
                if (_PushToDatabaseCommand == null) _PushToDatabaseCommand = new RelayCommand(param => pushToDatabase(), param => { return (queries.Count > 0); });

                return _PushToDatabaseCommand;
            }
        }
        private void pushToDatabase()
        {
            using (SqlConnection con = new SqlConnection(App.connString))
            {
                con.Open();

                foreach (vmQueryItem queryitem in queries)
                {
                    if (queryitem.Type == "Add")
                        ((vmAddQueryItem)queryitem).CreateQueryNExecute(con);
                    else if (queryitem.Type == "Edit")
                        ((vmEditQueryItem)queryitem).CreateQueryNExecute(con);
                    else
                        ((vmRemoveQueryItem)queryitem).CreateQueryNExecute(con);
                }

                queries.Clear();

                con.Close();
            }

            App.RuleVM.basic();
            App.ProgramsVM.basic();
        }

        #endregion

        #region Methods

        public void Remove(vmQueryItem query)
        {
            queries.Remove(query);
        }
        public void Add(vmQueryItem query)
        {
            queries.Add(query);
        }

        #endregion
    }
}
