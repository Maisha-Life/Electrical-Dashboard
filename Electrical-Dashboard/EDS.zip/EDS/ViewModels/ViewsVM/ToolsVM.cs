﻿using EDS.ViewModels.ModelsVM;
using MVVM.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;

namespace EDS.ViewModels.ViewsVM
{
    public class ToolsVM : BaseVM
    {
        public ToolsVM()
        {
            foreach (vmTool tool in App.ProgramsVM.EDSData.tools)
                _ToolsList.Add(tool);           

            initializeToolsCollection();
        }

        #region Data Binds      

        private readonly ObservableCollection<vmTool> _ToolsList = new ObservableCollection<vmTool>();
        public ICollectionView ToolsList { get; set; }

        private string _SearchString = "";
        public string SearchString
        {
            get { return _SearchString; }
            set
            {
                if (this._SearchString != value)
                {
                    this._SearchString = value;
                    ToolsList.Refresh();
                    this.RaisePropertyChangedEvent("SearchString");
                }
            }
        }

        private int _TabIndex;
        public int TabIndex
        {
            get { return _TabIndex; }
            set
            {
                if (this._TabIndex != value)
                {
                    this._TabIndex = value;
                    this.RaisePropertyChangedEvent("TabIndex");
                }
            }
        }

        #endregion

        #region Search

        public void initializeToolsCollection()
        {
            ToolsList = CollectionViewSource.GetDefaultView(_ToolsList);
            ToolsList.Filter = new Predicate<object>(SearchFilter);
            ToolsList.SortDescriptions.Add(new SortDescription("Name", ListSortDirection.Ascending));
        }
        public bool SearchFilter(object o)
        {
            vmTool item = o as vmTool;

            string itemString = item.Name;

            if (itemString != null && itemString.IndexOf(_SearchString, StringComparison.OrdinalIgnoreCase) >= 0)
                return true;

            return false;
        }

        #endregion

        #region Commands

        private RelayCommand _ListViewCommand;
        public ICommand ListViewCommand
        {
            get
            {
                if (_ListViewCommand == null) _ListViewCommand = new RelayCommand(param => listViewCommand(), param => { return (TabIndex != 1); });

                return _ListViewCommand;
            }
        }
        private void listViewCommand()
        {
            TabIndex = 1;
        }

        private RelayCommand _GridViewCommand;
        public ICommand GridViewCommand
        {
            get
            {
                if (_GridViewCommand == null) _GridViewCommand = new RelayCommand(param => gridViewCommand(), param => { return (TabIndex != 0); });

                return _GridViewCommand;
            }
        }
        private void gridViewCommand()
        {
            TabIndex = 0;
        }
      
        #endregion
    }
}
