﻿using System.Windows.Input;

using MVVM.Utilities;

using EDS.Utilities;

namespace EDS.ViewModels.ViewsVM
{
    public class ToolBarVM : BaseVM
    {
        public ToolBarVM()
        {
            PinnedBool = true;
        }
        #region Data Binds

        private bool _PinnedBool;
        public bool PinnedBool
        {
            get { return _PinnedBool; }
            set
            {
                if (this._PinnedBool != value)
                {
                    this._PinnedBool = value;
                    this.RaisePropertyChangedEvent("PinnedBool");
                }
            }
        }
        
        #endregion

        #region Commands

        private RelayCommand _CloseCommand;
        public ICommand CloseCommand
        {
            get
            {
                if (_CloseCommand == null) _CloseCommand = new RelayCommand(param => closecommand(), param => { return (true); });

                return _CloseCommand;
            }
        }
        private void closecommand()
        {
            ToolBarHelper.Close();
            PinnedBool = true;
        }

        private RelayCommand _PinnedToggleCommand;
        public ICommand PinnedToggleCommand
        {
            get
            {
                if (_PinnedToggleCommand == null) _PinnedToggleCommand = new RelayCommand(param => pinnedToggle(), param => { return (true); });

                return _PinnedToggleCommand;
            }
        }
        private void pinnedToggle()
        {
            PinnedBool = !PinnedBool;
        }


        #endregion
    }
}
