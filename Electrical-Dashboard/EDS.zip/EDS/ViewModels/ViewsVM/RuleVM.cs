﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Data;
using System.Windows.Input;
using EDS.Data;
using EDS.Models;
using EDS.Utilities;
using EDS.ViewModels.ModelsVM;

using MVVM.Utilities;

namespace EDS.ViewModels.ViewsVM
{
    public class RuleVM : BaseVM
    {
        public RuleVM()
        {
            RuleData.grabData();

            _ruleList = RuleData.RuleList;

            populateFilters();
            initializeRulezCollection();

            countStatus();
        }

        #region Properties

        vmRuleAll rule = null;

        private string[] filters = new string[] { " ---- ", "Good", "Warning", "Error", "Question", "Automated", "Manual" };

        private RuleData _RuleData;
        public RuleData RuleData
        {
            get { return _RuleData ?? (_RuleData = new RuleData()); }
            set { this._RuleData = value; }
        }

        #endregion

        #region Search

        public void initializeRulezCollection()
        {
            ruleList = CollectionViewSource.GetDefaultView(_ruleList);
            ruleList.Filter = SearchFilter;
            ruleList.SortDescriptions.Add(new SortDescription("DesignRule", ListSortDirection.Ascending));

            PropertyGroupDescription groupDescription = new PropertyGroupDescription("AuthorProp.Saved");
            ruleList.GroupDescriptions.Add(groupDescription);
        }
        public bool SearchFilter(object o)
        {
            rule = o as vmRuleAll;

            string statusString;

            if (selectedFilterIndex < 4)
            {
                if (selectedFilterIndex == 1) statusString = "0";
                else if (selectedFilterIndex == 2) statusString = "1";
                else if (selectedFilterIndex == 3) statusString = "2";
                else return testString(rule);

                if (statusString.Contains(rule.Id_Status.ToString())) return testString(rule);

                else return false;
            }
            else
            {
                if (selectedFilterIndex == 5)
                    if (rule.RepairBool == "True" || rule.CheckBool == "True")
                        return testString(rule);
                    else
                        return false;
                else if (selectedFilterIndex == 6)
                    if (rule.RepairBool == "True" || rule.CheckBool == "True")
                        return false;
                    else
                        return testString(rule);
                else
                    return rule.QuestionBool;
            }
        }
        private bool testString(vmRuleAll rule)
        {
            string searchstring = rule.DesignRule + rule.RuleName + rule.LegacyIDDesc + rule.RuleDesc;

            if (searchstring != null && searchstring.ToUpper().Contains(_SearchString.ToUpper()))
                return true;

            return false;
        }

        #endregion

        #region Data Binds

        public readonly ObservableCollection<vmRuleBase> _ruleList = new ObservableCollection<vmRuleBase>();
        public ICollectionView ruleList { get; set; }

        private string _SearchString = "";
        public string SearchString
        {
            get { return _SearchString; }
            set
            {
                if (this._SearchString != value)
                {
                    this._SearchString = value;

                    if (_SearchString == "")
                        executeSearch();

                    this.RaisePropertyChangedEvent("SearchString");
                }
            }
        }

        private ObservableCollection<string> _filtersList;
        public ObservableCollection<string> filtersList
        {
            get { return _filtersList ?? (_filtersList = new ObservableCollection<string>()); }
            set
            {
                if (this._filtersList != value)
                {
                    this._filtersList = value;
                    this.RaisePropertyChangedEvent("filtersList");
                }
            }
        }

        private string _selectedFilter;
        public string selectedFilter
        {
            get { return _selectedFilter; }
            set
            {
                if (this._selectedFilter != value)
                {
                    this._selectedFilter = value;
                    this.RaisePropertyChangedEvent("selectedFilter");
                }
            }
        }
        private int _selectedFilterIndex;
        public int selectedFilterIndex
        {
            get { return _selectedFilterIndex; }
            set
            {
                if (this._selectedFilterIndex != value)
                {
                    this._selectedFilterIndex = value;
                    refreshList();
                    countStatus();
                    this.RaisePropertyChangedEvent("selectedFilterIndex");
                }
            }
        }

        private int _totalCount;
        public int totalCount
        {
            get { return _totalCount; }
            set
            {
                if (this._totalCount != value)
                {
                    this._totalCount = value;
                    this.RaisePropertyChangedEvent("totalCount");
                }
            }
        }

        private int _questionCount;
        public int questionCount
        {
            get { return _questionCount; }
            set
            {
                if (this._questionCount != value)
                {
                    this._questionCount = value;
                    this.RaisePropertyChangedEvent("questionCount");
                }
            }
        }

        private int _questionAnswerCount;
        public int questionAnswerCount
        {
            get { return _questionAnswerCount; }
            set
            {
                if (this._questionAnswerCount != value)
                {
                    this._questionAnswerCount = value;
                    this.RaisePropertyChangedEvent("questionAnswerCount");
                }
            }
        }

        private int _goodCount;
        public int goodCount
        {
            get { return _goodCount; }
            set
            {
                if (this._goodCount != value)
                {
                    this._goodCount = value;
                    this.RaisePropertyChangedEvent("goodCount");
                }
            }
        }

        private int _warningCount;
        public int warningCount
        {
            get { return _warningCount; }
            set
            {
                if (this._warningCount != value)
                {
                    this._warningCount = value;
                    this.RaisePropertyChangedEvent("warningCount");
                }
            }
        }

        private int _errorCount;
        public int errorCount
        {
            get { return _errorCount; }
            set
            {
                if (this._errorCount != value)
                {
                    this._errorCount = value;
                    this.RaisePropertyChangedEvent("errorCount");
                }
            }
        }

        #endregion

        #region Commands

        private RelayCommand _AddNewRule;
        public ICommand AddNewRule
        {
            get
            {
                if (_AddNewRule == null) _AddNewRule = new RelayCommand(param => addNewRule(), param => { return (true); });

                return _AddNewRule;
            }
        }
        private void addNewRule()
        {
            vmRuleAll newRule = new vmRuleAll(Rule.CreateRule(), _ruleList, true);

            newRule.newRule();

            PopupHelper.TabIndex(7, newRule);
            PopupHelper.SetVisibility(true);
        }

        private RelayCommand _ExecuteSearchCommand;
        public ICommand ExecuteSearchCommand
        {
            get
            {
                if (_ExecuteSearchCommand == null) _ExecuteSearchCommand = new RelayCommand(param => executeSearch(), param => { return (true); });

                return _ExecuteSearchCommand;
            }
        }
        private void executeSearch()
        {
            ruleList.Refresh();
        }

        #endregion

        #region Methods

        private void countStatus()
        {
            totalCount = 0;

            goodCount = 0;
            warningCount = 0;
            errorCount = 0;

            questionCount = 0;
            questionAnswerCount = 0;

            foreach (vmRuleAll ruleBase in ruleList)
            {
                if (ruleBase.Id_Status == 0)
                    goodCount++;
                else if (ruleBase.Id_Status == 1)
                    warningCount++;
                else if (ruleBase.Id_Status == 2)
                    errorCount++;

                questionCount += ruleBase.questions.Count;

                totalCount++;
            }
        }
        private void populateFilters()
        {
            foreach (string filterstring in filters) filtersList.Add(filterstring);
        }

        public void basic()
        {
            RuleData.grabData();

            countStatus();

            ruleList.Refresh();
        }

        private async void refreshList()
        {
            ruleList.Refresh();
        }

        #endregion
    }
}
