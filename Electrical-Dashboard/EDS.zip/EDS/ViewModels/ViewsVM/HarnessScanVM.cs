﻿using System.Windows.Input;

using EDS.ViewModels.ModelsVM;
using EDS.Data;

using MVVM.Utilities;
using EDS.ViewModels.ModelsVM.Scans.Harness;

namespace EDS.ViewModels.ViewsVM
{
    public class HarnessScanVM : BaseVM
    {
        public HarnessScanVM()
        {

        }

        #region Data Binds

        private bool _gridDisplayBool;
        public bool gridDisplayBool
        {
            get { return _gridDisplayBool; }
            set
            {
                if (this._gridDisplayBool != value)
                {
                    this._gridDisplayBool = value;
                    this.RaisePropertyChangedEvent("gridDisplayBool");
                }
            }
        }
        
        private bool _harnessSelectedBool;
        public bool harnessSelectedBool
        {
            get { return _harnessSelectedBool; }
            set
            {
                if (this._harnessSelectedBool != value)
                {
                    this._harnessSelectedBool = value;
                    this.RaisePropertyChangedEvent("harnessSelectedBool");
                }
            }
        }

        private vmHarness _SelectedHarness;
        public vmHarness SelectedHarness
        {
            get { return _SelectedHarness; }
            set
            {
                if (this._SelectedHarness != value)
                {
                    this._SelectedHarness = value;
                    this.RaisePropertyChangedEvent("SelectedHarness");
                }
            }
        }

        #endregion

        #region Commands

        private RelayCommand _SelectNewHarnessCommand;
        public ICommand SelectNewHarnessCommand
        {
            get
            {
                if (_SelectNewHarnessCommand == null) _SelectNewHarnessCommand = new RelayCommand(param => selectNewHarness(), param => { return (true); });

                return _SelectNewHarnessCommand;
            }
        }
        private void selectNewHarness()
        {
            //warning box here...
            gridDisplayBool = false;
            harnessSelectedBool = false;
            SelectedHarness = null;
        }

        public ICommand NewHarnessScanCommand
        {
            get { return new RelayCommand<string>(newHarnessScan); }
        }
        private void newHarnessScan(string harnessType)
        {
            BaseHarness BaseHarness = new BaseHarness();

            if (harnessType == "XML")
                BaseHarness = new XMLHarness();
            if (harnessType == "CAT")
                BaseHarness = new CATHarness();

            if (BaseHarness.connection)
            {
                BaseHarness.grabData();

                vmHarness newHarness = new vmHarness();

                string[] name = BaseHarness.name.Split('-');
                //assuming full harness...
                newHarness.ProgramName = name[0];
                newHarness._harness.HarnessDesc = name[1] + '-' + name[2].Split('_')[0];
                newHarness._harness.Revision = name[2].Split('_')[1];
                newHarness._harness.Owner = System.Environment.UserName;

                newHarness.Bundles = BaseHarness.bundles;
                newHarness.Devices = BaseHarness.devices;

                foreach (vmDevice device in newHarness.Devices)
                    if (device.DeviceType == "Fixing")
                        newHarness.ConnectorCount++;
                    else
                        newHarness.RetainerCount++;

                newHarness.harnessType = (BaseHarness.GetType().ToString() == "EDS.Data.XMLHarness") ? "xml" : "catia";

                SelectedHarness = newHarness;

                SelectedHarness.autoToolScan();

                gridDisplayBool = true;
                harnessSelectedBool = true;
            }
        }

        #endregion

        #region Methods       

        public void reset()
        {
            selectNewHarness();
        }

        #endregion
    }
}
