﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;

using EDS.Models;
using EDS.Utilities;
using EDS.Views.Popups;
using MVVM.Utilities;

using SQLQueryVM;

namespace EDS.ViewModels.ModelsVM
{
    public class vmProgram : vmScanBase, IDataErrorInfo
    {
        public readonly Program _program;
        public readonly ObservableCollection<vmProgram> _programs;

        #region Constructor

        public vmProgram() { }

        public vmProgram(Program program, ObservableCollection<vmProgram> programs)
        {
            if (program == null)
                throw new ArgumentNullException("program");
            if (programs == null)
                throw new ArgumentNullException("programs");

            _program = program;
            _programs = programs;

            Visibility = Visibility.Hidden;

            //grabCounts();
        }

        #endregion

        #region Data Binds

        private ThreeNOne _ProgramDescProp;
        public ThreeNOne ProgramDescProp
        {
            get
            {
                if (_ProgramDescProp == null)
                    _ProgramDescProp = new ThreeNOne(_program.ProgramDesc);

                return _ProgramDescProp;
            }
            set
            {
                if (_ProgramDescProp != value)
                {
                    _ProgramDescProp = value;
                    _program.ProgramDesc = _ProgramDescProp.Changed;
                    this.RaisePropertyChangedEvent("ProgramDescProp");
                }
            }
        }
        public string ProgramDesc
        {
            get { return ProgramDescProp.Changed; }
            set
            {
                if (this._ProgramDescProp.Changed != value)
                    this._ProgramDescProp.Changed = value;

                _program.ProgramDesc = value;
                this.RaisePropertyChangedEvent("ProgramDesc");
            }
        }

        private ThreeNOne _OwnerProp;
        public ThreeNOne OwnerProp
        {
            get
            {
                if (_OwnerProp == null)
                    _OwnerProp = new ThreeNOne(_program.Owner);

                return _OwnerProp;
            }
            set
            {
                if (_OwnerProp != value)
                {
                    _OwnerProp = value;
                    _program.Owner = _OwnerProp.Changed;
                    this.RaisePropertyChangedEvent("OwnerProp");
                }
            }
        }
        public string Owner
        {
            get { return OwnerProp.Changed; }
            set
            {
                if (this._OwnerProp.Changed != value)
                    this._OwnerProp.Changed = value;

                _program.Owner = value;
                this.RaisePropertyChangedEvent("Owner");
            }
        }

        private ObservableCollection<vmHarness> _Harnesses;
        public ObservableCollection<vmHarness> Harnesses
        {
            get
            {
                if (_Harnesses == null)
                    _Harnesses = new ObservableCollection<vmHarness>();
                return _Harnesses;
            }
            set
            {
                if (this._Harnesses != value)
                {
                    this._Harnesses = value;
                    this.RaisePropertyChangedEvent("Harnesses");
                }
            }
        }

        #endregion

        #region Commands
        //not sure if need this
        private RelayCommand _AddHarnessCommand;
        public ICommand AddHarnessCommand
        {
            get
            {
                if (_AddHarnessCommand == null) _AddHarnessCommand = new RelayCommand(param => addHarness(), param => { return (true); });

                return _AddHarnessCommand;
            }
        }
        private void addHarness()
        {
            vmHarness harness = new vmHarness(Harness.CreateHarness(), Harnesses, this);

            PopupHelper.TabIndex(3, harness);
            PopupHelper.SetVisibility(true);
        }

        private RelayCommand _SelectProgramCommand;
        public ICommand SelectProgramCommand
        {
            get
            {
                if (_SelectProgramCommand == null) _SelectProgramCommand = new RelayCommand(param => selectProgram(), param => { return (true); });

                return _SelectProgramCommand;
            }
        }
        private void selectProgram()
        {
            App.ProgramsVM.SelectedProgram = this;

            try
            {
                App.ProgramsVM.SelectedHarness.Visibility = Visibility.Hidden;
            }
            catch { }
            App.ProgramsVM.HomeVisibility = Visibility.Hidden;


            Visibility = Visibility.Visible;
        }

        private RelayCommand _ReturnHomeCommand;
        public ICommand ReturnHomeCommand
        {
            get
            {
                if (_ReturnHomeCommand == null) _ReturnHomeCommand = new RelayCommand(param => returnHome(), param => { return (true); });

                return _ReturnHomeCommand;
            }
        }
        private void returnHome()
        {
            Visibility = Visibility.Hidden;

            App.ProgramsVM.GetStatistics();

            App.ProgramsVM.HomeVisibility = Visibility.Visible;
        }

        private RelayCommand _AddProgramCommand;
        public ICommand AddProgramCommand
        {
            get
            {
                if (_AddProgramCommand == null) _AddProgramCommand = new RelayCommand(param => addProgram(), param => { return (_program.IsValid); });

                return _AddProgramCommand;
            }
        }
        private void addProgram()
        {
            Save();

            PopupHelper.SetVisibility(false);

            _programs.Add(this);

            App.MainQuery.queries.Add(new vmAddQueryItem(this, App.MainQuery));
        }

        private RelayCommand _EditProgramCommand;
        public ICommand EditProgramCommand
        {
            get
            {
                if (_EditProgramCommand == null) _EditProgramCommand = new RelayCommand(param => editProgram(), param => { return (true); });

                return _EditProgramCommand;
            }
        }
        private void editProgram()
        {
            EditBool = true;

            PopupHelper.TabIndex(6, this);
            PopupHelper.SetVisibility(true);
        }

        private RelayCommand _SaveProgramCommand;
        public ICommand SaveProgramCommand
        {
            get
            {
                if (_SaveProgramCommand == null) _SaveProgramCommand = new RelayCommand(param => saveProgram(), param => { return (_program.IsValid); });

                return _SaveProgramCommand;
            }
        }
        private void saveProgram()
        {
            EditBool = false;

            Save();

            PopupHelper.SetVisibility(false);

            App.MainQuery.queries.Add(new vmEditQueryItem(this, App.MainQuery));
        }

        private RelayCommand _CancelProgramCommand;
        public ICommand CancelProgramCommand
        {
            get
            {
                if (_CancelProgramCommand == null) _CancelProgramCommand = new RelayCommand(param => cancelProgram(), param => { return (true); });

                return _CancelProgramCommand;
            }
        }
        private void cancelProgram()
        {
            Cancel();

            PopupHelper.SetVisibility(false);
        }

        private RelayCommand _RemoveProgramCommand;
        public ICommand RemoveProgramCommand
        {
            get
            {
                if (_RemoveProgramCommand == null) _RemoveProgramCommand = new RelayCommand(param => removeProgram(), param => { return (true); });

                return _RemoveProgramCommand;
            }
        }
        private void removeProgram()
        {
            if (WarningMessageBox.ShowBox(ProgramDesc, "Programs") == System.Windows.Forms.DialogResult.Yes)
            {
                App.MainQuery.queries.Add(new vmRemoveQueryItem(this, App.MainQuery));

                Remove();
            }
        }

        #endregion

        #region Methods

        public override void Save()
        {
            ProgramDescProp.Save();
            OwnerProp.Save();

            SaveProps();
        }
        public override void Cancel()
        {
            ProgramDescProp.Cancel();
            OwnerProp.Cancel();

            SaveProps();
        }
        public override void Remove()
        {
            _programs.Remove(this);
        }
        public override void Revert()
        {
            ProgramDescProp.Default();
            OwnerProp.Default();

            SaveProps();
        }

        private void SaveProps()
        {
            ProgramDesc = ProgramDescProp.Saved;
            Owner = OwnerProp.Saved;
        }

        public override void GetStatistics()
        {
            GoodCount = 0;
            WarningCount = 0;
            ErrorCount = 0;

            TotalCount = 0;

            foreach (vmHarness harness in Harnesses)
            {
                harness.GetStatistics();

                GoodCount += harness.GoodCount;
                WarningCount += harness.WarningCount;
                ErrorCount += harness.ErrorCount;

                TotalCount += harness.TotalCount;
            }

            TotalCount = GoodCount + WarningCount + ErrorCount;
        }

        #endregion

        #region IDataErrorInfo Members

        string IDataErrorInfo.Error { get { return (_program as IDataErrorInfo).Error; } }

        string IDataErrorInfo.this[string propertyName]
        {
            get
            {
                string error = null;
                error = (_program as IDataErrorInfo)[propertyName];
                return error;
            }
        }

        #endregion
    }
}