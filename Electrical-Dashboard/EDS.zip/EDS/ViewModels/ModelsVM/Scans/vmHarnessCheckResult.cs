﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;

using EDS.Models;

namespace EDS.ViewModels.ModelsVM
{
    public class vmHarnessCheckResult : vmScanBase, IDataErrorInfo
    {
        public vmHarnessRule _harnessrule { get; set; }

        public readonly HarnessCheckResult _harnessCheckResult;
        public readonly ObservableCollection<vmHarnessCheckResult> _checks;

        public vmHarnessCheckResult(HarnessCheckResult check, vmHarnessRule harnessrule)
        {
            _harnessCheckResult = check ?? throw new ArgumentNullException("check");
            _harnessrule = harnessrule ?? throw new ArgumentNullException("harnessrule");
        }

        #region Data Binds

        private string _HarnessCheckResultDesc;
        public string HarnessCheckResultDesc
        {
            get
            {
                if (_HarnessCheckResultDesc == null)
                    _HarnessCheckResultDesc = _harnessCheckResult.HarnessCheckResultDesc;

                return _HarnessCheckResultDesc;
            }
            set
            {
                _HarnessCheckResultDesc = value;
                _harnessCheckResult.HarnessCheckResultDesc = _HarnessCheckResultDesc;
                this.RaisePropertyChangedEvent("HarnessCheckResultDesc");
            }
        }

        private string _Id_Status;
        public string Id_Status
        {
            get
            {
                if (_Id_Status == null)
                    _Id_Status = _harnessCheckResult.Id_Status;

                return _Id_Status;
            }
            set
            {
                _Id_Status = value;
                _harnessCheckResult.Id_Status = _Id_Status;
                this.RaisePropertyChangedEvent("Id_Status");
            }
        }        

        #endregion

        #region Commands



        #endregion

        #region Methods

        public override void Save()
        {

        }
        public override void Cancel()
        {

        }
        public override void Remove()
        {

        }
        public override void Revert()
        {

        }

        private void SaveProps()
        {

        }

        #endregion

        #region IDataErrorInfo Members

        string IDataErrorInfo.Error { get { return (_harnessCheckResult as IDataErrorInfo).Error; } }

        string IDataErrorInfo.this[string propertyName]
        {
            get
            {
                string error = null;
                error = (_harnessCheckResult as IDataErrorInfo)[propertyName];
                return error;
            }
        }

        #endregion
    }
}