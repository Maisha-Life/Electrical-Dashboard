﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Input;

using EDS.Models;
using MVVM.Utilities;

namespace EDS.ViewModels.ModelsVM
{
    public class vmHarnessRule : vmRuleBase
    {
        public readonly vmHarness _harness;

        public vmHarnessRule(vmHarness harness, Rule rule) : base(rule)
        {
            _harness = harness ?? throw new ArgumentNullException("harness");
            _SelectedRuleBool = true;

            GetStatistics();
        }

        #region Data Binds

        private bool _SelectedRuleBool;
        public bool SelectedRuleBool
        {
            get { return _SelectedRuleBool; }
            set
            {
                if (this._SelectedRuleBool != value)
                {
                    this._SelectedRuleBool = value;
                    // _harness.HarnessRules.Refresh();
                    _harness.GetSelected();
                    this.RaisePropertyChangedEvent("SelectedRuleBool");
                }
            }
        }

        private int _GoodCount;
        public int GoodCount
        {
            get { return _GoodCount; }
            set
            {
                if (this._GoodCount != value)
                {
                    this._GoodCount = value;
                    this.RaisePropertyChangedEvent("GoodCount");
                }
            }
        }

        private int _WarningCount;
        public int WarningCount
        {
            get { return _WarningCount; }
            set
            {
                if (this._WarningCount != value)
                {
                    this._WarningCount = value;
                    this.RaisePropertyChangedEvent("WarningCount");
                }
            }
        }

        private int _ErrorCount;
        public int ErrorCount
        {
            get { return _ErrorCount; }
            set
            {
                if (this._ErrorCount != value)
                {
                    this._ErrorCount = value;
                    this.RaisePropertyChangedEvent("ErrorCount");
                }
            }
        }

        public int TotalCount { get; set; }

        private ObservableCollection<vmHarnessCheckResult> _HarnessRuleChecks;
        public ObservableCollection<vmHarnessCheckResult> HarnessRuleChecks
        {
            get { return _HarnessRuleChecks ?? (_HarnessRuleChecks = new ObservableCollection<vmHarnessCheckResult>()); }
            set
            {
                if (this._HarnessRuleChecks != value)
                {
                    this._HarnessRuleChecks = value;
                    GetStatistics();
                    this.RaisePropertyChangedEvent("HarnessRuleChecks");
                }
            }
        }

        #endregion

        #region Commands

        private RelayCommand _CheckMethodCommand;
        public ICommand CheckMethodCommand
        {
            get
            {
                if (_CheckMethodCommand == null) _CheckMethodCommand = new RelayCommand(param => checkMethod(), param => { return (true); });

                return _CheckMethodCommand;
            }
        }
        private void checkMethod()
        {

        }

        private RelayCommand _RepairMethodCommand;
        public ICommand RepairMethodCommand
        {
            get
            {
                if (_RepairMethodCommand == null) _RepairMethodCommand = new RelayCommand(param => repairMethod(), param => { return (true); });

                return _RepairMethodCommand;
            }
        }
        private void repairMethod()
        {

        }

        private RelayCommand _FixAllWalkthroughCommand;
        public ICommand FixAllWalkthroughCommand
        {
            get
            {
                if (_FixAllWalkthroughCommand == null) _FixAllWalkthroughCommand = new RelayCommand(param => fixAllWalkthrough(), param => { return (true); });

                return _FixAllWalkthroughCommand;
            }
        }
        private void fixAllWalkthrough()
        {
            Utilities.PopupHelper.TabIndex(1, this);
            Utilities.PopupHelper.SetVisibility(true);
        }

        private RelayCommand _RequestExceptionCommand;
        public ICommand RequestExceptionCommand
        {
            get
            {
                if (_RequestExceptionCommand == null) _RequestExceptionCommand = new RelayCommand(param => requestException(), param => { return (false); });

                return _RequestExceptionCommand;
            }
        }
        private void requestException()
        {

        }

        private RelayCommand _CompleteRuleCommand;
        public ICommand CompleteRuleCommand
        {
            get
            {
                if (_CompleteRuleCommand == null) _CompleteRuleCommand = new RelayCommand(param => completeRule(), param => { return (true); });

                return _CompleteRuleCommand;
            }
        }
        private void completeRule()
        {
            save();

            _harness.GetStatistics();

            Utilities.PopupHelper.SetVisibility(false);
        }
        public void save()
        {
            GoodCount = 1;
            ErrorCount = 0;
            WarningCount = 0;

            _harness.GetStatistics();
        }

        private RelayCommand _CancelHarnessFixCommand;
        public ICommand CancelHarnessFixCommand
        {
            get
            {
                if (_CancelHarnessFixCommand == null) _CancelHarnessFixCommand = new RelayCommand(param => cancelharnessFix(), param => { return (true); });

                return _CancelHarnessFixCommand;
            }
        }
        private void cancelharnessFix()
        {
            Cancel();

            Utilities.PopupHelper.SetVisibility(false);
        }

        #endregion

        #region Methods

        public void GetStatistics()
        {
            if (TotalCount != 1)
            {
                GoodCount = 0;
                WarningCount = 0;
                ErrorCount = 0;
                TotalCount = 0;

                foreach (vmHarnessCheckResult harnessCheckResult in HarnessRuleChecks)
                {
                    if (harnessCheckResult.Id_Status == "0")
                        GoodCount++;
                    else if (harnessCheckResult.Id_Status == "1")
                        WarningCount++;
                    else
                        ErrorCount++;

                    TotalCount++;
                }

                if (TotalCount == 0)
                {
                    ErrorCount = 1;
                    TotalCount = 1;
                }
            }
        }

        #endregion
    }
}
