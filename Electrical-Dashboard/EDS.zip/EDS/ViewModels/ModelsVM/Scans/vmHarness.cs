﻿using System;
using System.Windows;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;

using EDS.Models;
using EDS.Utilities;

using MVVM.Utilities;

using SQLQueryVM;
using EDS.ViewModels.ModelsVM.Scans.Harness;
using System.Windows.Data;
using System.Threading.Tasks;

namespace EDS.ViewModels.ModelsVM
{
    public class vmHarness : vmScanBase, IDataErrorInfo
    {
        public readonly Harness _harness;
        public readonly ObservableCollection<vmHarness> _harnesses;
        public readonly vmProgram _program;

        #region Constructor

        public vmHarness()
        {
            _harness = Harness.CreateHarness();

            RetainerCount = 0;
            ConnectorCount = 0;
            resetToolBools();
            harnessScanReadyBool = false;
            startScanPromptBool = false;

            initializeRuleViewCollection();
        }

        public vmHarness(Harness harness, ObservableCollection<vmHarness> harnesses, vmProgram program)
        {
            Visibility = Visibility.Hidden;

            _harness = harness ?? throw new ArgumentNullException("harness");
            _harnesses = harnesses ?? throw new ArgumentNullException("harnesses");
            _program = program ?? throw new ArgumentNullException("program");
        }

        #endregion

        #region Search

        vmHarnessRule rule = null;

        public void initializeRuleViewCollection()
        {
            HarnessRules = CollectionViewSource.GetDefaultView(_HarnessRules);
            HarnessRules.Filter = SearchFilter;

            //HarnessRules.SortDescriptions.Add(new SortDescription("SelectedRuleBool", ListSortDirection.Descending));
            HarnessRules.SortDescriptions.Add(new SortDescription("DesignRule", ListSortDirection.Ascending));

            PropertyGroupDescription groupDescription = new PropertyGroupDescription();
            groupDescription.PropertyName = "SelectedRuleBool";
            HarnessRules.GroupDescriptions.Add(groupDescription);

        }
        public bool SearchFilter(object o)
        {
            rule = o as vmHarnessRule;

            if ((rule.RuleName + rule.RuleDesc + rule.DesignRule + rule.LegacyIDDesc).Contains(SearchString))
                return true;

            return false;
        }

        private readonly ObservableCollection<vmHarnessRule> _HarnessRules = new ObservableCollection<vmHarnessRule>();
        public ICollectionView HarnessRules { get; set; }

        private string _SearchString = "";
        public string SearchString
        {
            get { return _SearchString; }
            set
            {
                if (this._SearchString != value)
                {
                    this._SearchString = value;
                    HarnessRules.Refresh();
                    this.RaisePropertyChangedEvent("SearchString");
                }
            }
        }

        #endregion

        #region Data Binds

        private bool _startScanPromptBool;
        public bool startScanPromptBool
        {
            get { return _startScanPromptBool; }
            set
            {
                this._startScanPromptBool = value;
                this.RaisePropertyChangedEvent("startScanPromptBool");

            }
        }

        public string harnessType { get; set; }

        private string _ProgramName;
        public string ProgramName
        {
            get { return _ProgramName; }
            set
            {
                if (this._ProgramName != value)
                {
                    this._ProgramName = value;
                    this.RaisePropertyChangedEvent("ProgramName");
                }
            }
        }

        private ThreeNOne _HarnessDescProp;
        public ThreeNOne HarnessDescProp
        {
            get
            {
                if (_HarnessDescProp == null)
                    _HarnessDescProp = new ThreeNOne(_harness.HarnessDesc);

                return _HarnessDescProp;
            }
            set
            {
                if (_HarnessDescProp != value)
                {
                    _HarnessDescProp = value;
                    _harness.HarnessDesc = _HarnessDescProp.Changed;
                    this.RaisePropertyChangedEvent("HarnessDescProp");
                }
            }
        }
        public string HarnessDesc
        {
            get { return HarnessDescProp.Changed; }
            set
            {
                if (this._HarnessDescProp.Changed != value)
                    this._HarnessDescProp.Changed = value;

                _harness.HarnessDesc = value;
                this.RaisePropertyChangedEvent("HarnessDesc");
            }
        }

        private ThreeNOne _RevisionProp;
        public ThreeNOne RevisionProp
        {
            get
            {
                if (_RevisionProp == null)
                    _RevisionProp = new ThreeNOne(_harness.Revision);

                return _RevisionProp;
            }
            set
            {
                if (_RevisionProp != value)
                {
                    _RevisionProp = value;
                    _harness.Revision = _RevisionProp.Changed;
                    this.RaisePropertyChangedEvent("RevisionProp");
                }
            }
        }
        public string Revision
        {
            get { return RevisionProp.Changed; }
            set
            {
                if (this._RevisionProp.Changed != value)
                    this._RevisionProp.Changed = value;

                _harness.Revision = value.Trim();
                this.RaisePropertyChangedEvent("Revision");
            }
        }

        private ThreeNOne _OwnerProp;
        public ThreeNOne OwnerProp
        {
            get
            {
                if (_OwnerProp == null)
                    _OwnerProp = new ThreeNOne(_harness.Owner);

                return _OwnerProp;
            }
            set
            {
                if (_OwnerProp != value)
                {
                    _OwnerProp = value;
                    _harness.Owner = _OwnerProp.Changed;
                    this.RaisePropertyChangedEvent("OwnerProp");
                }
            }
        }
        public string Owner
        {
            get { return OwnerProp.Changed; }
            set
            {
                if (this._OwnerProp.Changed != value)
                    this._OwnerProp.Changed = value;

                _harness.Owner = value;
                this.RaisePropertyChangedEvent("Owner");
            }
        }

        private bool _ToolsScanBool;
        public bool ToolsScanBool
        {
            get
            {
                _ToolsScanBool = _harness.ToolsScanBool;

                return _ToolsScanBool;
            }
            set
            {
                _ToolsScanBool = value;
                _harness.ToolsScanBool = _ToolsScanBool;
                this.RaisePropertyChangedEvent("ToolsScanBool");
            }
        }

        private bool _PMIBool;
        public bool PMIBool
        {
            get
            {
                _PMIBool = _harness.PMIBool;

                return _PMIBool;
            }
            set
            {
                _PMIBool = value;
                _harness.PMIBool = _PMIBool;
                checkToolBools();
                this.RaisePropertyChangedEvent("PMIBool");
            }
        }
        private bool _DTSyncBool;
        public bool DTSyncBool
        {
            get
            {
                _DTSyncBool = _harness.DTSyncBool;

                return _DTSyncBool;
            }
            set
            {
                _DTSyncBool = value;
                _harness.DTSyncBool = _DTSyncBool;
                checkToolBools();
                this.RaisePropertyChangedEvent("DTSyncBool");
            }
        }
        private bool _FFA2Bool;
        public bool FFA2Bool
        {
            get
            {
                _FFA2Bool = _harness.FFA2Bool;

                return _FFA2Bool;
            }
            set
            {
                _FFA2Bool = value;
                _harness.FFA2Bool = _FFA2Bool;
                checkToolBools();
                this.RaisePropertyChangedEvent("FFA2Bool");
            }
        }
        private bool _RenamingBool;
        public bool RenamingBool
        {
            get
            {
                _RenamingBool = _harness.RenamingBool;

                return _RenamingBool;
            }
            set
            {
                _RenamingBool = value;
                _harness.RenamingBool = _RenamingBool;
                checkToolBools();
                this.RaisePropertyChangedEvent("RenamingBool");
            }
        }
        private bool _CouponBool;
        public bool CouponBool
        {
            get { return _CouponBool; }
            set
            {
                if (this._CouponBool != value)
                {
                    this._CouponBool = value;
                    checkToolBools();
                    this.RaisePropertyChangedEvent("CouponBool");
                }
            }
        }

        private bool _HarnessCheckBool;
        public bool HarnessCheckBool
        {
            get
            {
                _HarnessCheckBool = _harness.HarnessCheckBool;

                return _HarnessCheckBool;
            }
            set
            {
                _HarnessCheckBool = value;
                _harness.HarnessCheckBool = _HarnessCheckBool;
                this.RaisePropertyChangedEvent("HarnessCheckBool");
            }
        }

        private int _SelectedRuleCount;
        public int SelectedRuleCount
        {
            get { return _SelectedRuleCount; }
            set
            {
                if (this._SelectedRuleCount != value)
                {
                    this._SelectedRuleCount = value;
                    this.RaisePropertyChangedEvent("SelectedRuleCount");
                }
            }
        }

        private bool _toolsScanReadyBool;
        public bool toolsScanReadyBool
        {
            get { return _toolsScanReadyBool; }
            set
            {
                if (this._toolsScanReadyBool != value)
                {
                    this._toolsScanReadyBool = value;

                    if (!value)
                        resetToolBools();

                    this.RaisePropertyChangedEvent("toolsScanReadyBool");
                }
            }
        }

        private bool _toolsMethodBool;
        public bool toolsMethodBool
        {
            get { return _toolsMethodBool; }
            set
            {
                if (this._toolsMethodBool != value)
                {
                    this._toolsMethodBool = value;
                    resetToolBools();
                    this.RaisePropertyChangedEvent("toolsMethodBool");
                }
            }
        }

        private int _toolsScanCompleteTerniary;
        public int toolsScanCompleteTerniary
        {
            get { return _toolsScanCompleteTerniary; }
            set
            {
                if (this._toolsScanCompleteTerniary != value)
                {
                    this._toolsScanCompleteTerniary = value;
                    this.RaisePropertyChangedEvent("toolsScanCompleteTerniary");
                }
            }
        }

        private bool _harnessScanSelectionReadyBool;
        public bool harnessScanSelectionReadyBool
        {
            get { return _harnessScanSelectionReadyBool; }
            set
            {
                if (this._harnessScanSelectionReadyBool != value)
                {
                    this._harnessScanSelectionReadyBool = value;
                    this.RaisePropertyChangedEvent("harnessScanSelectionReadyBool");
                }
            }
        }
        private bool _harnessScanReadyBool;
        public bool harnessScanReadyBool
        {
            get { return _harnessScanReadyBool; }
            set
            {
                if (this._harnessScanReadyBool != value)
                {
                    this._harnessScanReadyBool = value;
                    this.RaisePropertyChangedEvent("harnessScanReadyBool");
                }
            }
        }

        #region Harness...

        private ObservableCollection<vmBundle> _Bundles;
        public ObservableCollection<vmBundle> Bundles
        {
            get { return _Bundles ?? (_Bundles = new ObservableCollection<vmBundle>()); }
            set
            {
                if (this._Bundles != value)
                {
                    this._Bundles = value;
                    this.RaisePropertyChangedEvent("Bundles");
                }
            }
        }

        private ObservableCollection<vmDevice> _Devices;
        public ObservableCollection<vmDevice> Devices
        {
            get { return _Devices ?? (_Devices = new ObservableCollection<vmDevice>()); }
            set
            {
                if (this._Devices != value)
                {
                    this._Devices = value;
                    this.RaisePropertyChangedEvent("Devices");
                }
            }
        }

        public int ConnectorCount { get; set; }
        public int RetainerCount { get; set; }

        #endregion

        #endregion

        #region Commands

        private RelayCommand _ExecuteSearchCommand;
        public ICommand ExecuteSearchCommand
        {
            get
            {
                if (_ExecuteSearchCommand == null) _ExecuteSearchCommand = new RelayCommand(param => executeSearch(), param => { return (true); });

                return _ExecuteSearchCommand;
            }
        }
        private void executeSearch()
        {
            HarnessRules.Refresh();
        }

        private RelayCommand _ReturnToProgramCommand;
        public ICommand ReturnToProgramCommand
        {
            get
            {
                if (_ReturnToProgramCommand == null) _ReturnToProgramCommand = new RelayCommand(param => returnToProgram(), param => { return (true); });

                return _ReturnToProgramCommand;
            }
        }
        private void returnToProgram()
        {
            Visibility = Visibility.Hidden;

            App.ProgramsVM.SelectedProgram.GetStatistics();

            App.ProgramsVM.SelectedProgram.Visibility = Visibility.Visible;
        }

        private RelayCommand _AddHarnessCommand;
        public ICommand AddHarnessCommand
        {
            get
            {
                if (_AddHarnessCommand == null) _AddHarnessCommand = new RelayCommand(param => addHarness(), param => { return (_harness.IsValid); });

                return _AddHarnessCommand;
            }
        }
        private void addHarness()
        {
            Save();

            PopupHelper.SetVisibility(false);

            _harnesses.Add(this);

            App.MainQuery.queries.Add(new vmAddQueryItem(this, App.MainQuery));
        }

        private RelayCommand _SelectHarnessCommand;
        public ICommand SelectHarnessCommand
        {
            get
            {
                if (_SelectHarnessCommand == null) _SelectHarnessCommand = new RelayCommand(param => selectHarness(), param => { return (true); });

                return _SelectHarnessCommand;
            }
        }
        private void selectHarness()
        {
            App.ProgramsVM.SelectedHarness = this;

            App.ProgramsVM.SelectedProgram.Visibility = Visibility.Hidden;
            App.ProgramsVM.HomeVisibility = Visibility.Hidden;

            Visibility = Visibility.Visible;
        }

        private RelayCommand _EditHarnessCommand;
        public ICommand EditHarnessCommand
        {
            get
            {
                if (_EditHarnessCommand == null) _EditHarnessCommand = new RelayCommand(param => editHarness(), param => { return (true); });

                return _EditHarnessCommand;
            }
        }
        private void editHarness()
        {
            EditBool = true;

            PopupHelper.TabIndex(4, this);
            PopupHelper.SetVisibility(true);
        }

        private RelayCommand _SaveHarnessCommand;
        public ICommand SaveHarnessCommand
        {
            get
            {
                if (_SaveHarnessCommand == null) _SaveHarnessCommand = new RelayCommand(param => saveHarness(), param => { return (_harness.IsValid); });

                return _SaveHarnessCommand;
            }
        }
        private void saveHarness()
        {
            EditBool = false;

            Save();

            PopupHelper.SetVisibility(false);

            App.MainQuery.queries.Add(new vmEditQueryItem(this, App.MainQuery));
        }

        private RelayCommand _CancelHarnessCommand;
        public ICommand CancelHarnessCommand
        {
            get
            {
                if (_CancelHarnessCommand == null) _CancelHarnessCommand = new RelayCommand(param => cancelHarness(), param => { return (true); });

                return _CancelHarnessCommand;
            }
        }
        private void cancelHarness()
        {
            Cancel();

            PopupHelper.SetVisibility(false);
        }

        private RelayCommand _RemoveHarnessCommand;
        public ICommand RemoveHarnessCommand
        {
            get
            {
                if (_RemoveHarnessCommand == null) _RemoveHarnessCommand = new RelayCommand(param => removeHarness(), param => { return (true); });

                return _RemoveHarnessCommand;
            }
        }
        private void removeHarness()
        {
            if (Views.Popups.WarningMessageBox.ShowBox(HarnessDesc, _program.ProgramDesc) == System.Windows.Forms.DialogResult.Yes)
            {
                App.MainQuery.queries.Add(new vmRemoveQueryItem(this, App.MainQuery));

                Remove();
            }
        }

        private RelayCommand _AutoToolScanCommand;
        public ICommand AutoToolScanCommand
        {
            get
            {
                if (_AutoToolScanCommand == null) _AutoToolScanCommand = new RelayCommand(param => autoToolScan(), param => { return (!toolsMethodBool); });

                return _AutoToolScanCommand;
            }
        }
        public void autoToolScan()
        {
            toolsMethodBool = false;

            toolsScanReadyBool = true;

            //if (harnessType == "catia")
            //    checkTools(Data.CATHarness.GrabProductDescription());
        }

        private RelayCommand _ContinueRuleSelectionCommand;
        public ICommand ContinueRuleSelectionCommand
        {
            get
            {
                if (_ContinueRuleSelectionCommand == null) _ContinueRuleSelectionCommand = new RelayCommand(param => continueRuleSelection(), param => { return (true); });

                return _ContinueRuleSelectionCommand;
            }
        }
        private async void continueRuleSelection()
        {
            await Task.Run(() =>
            {
                for (int i = 0; i < App.RuleVM._ruleList.Count; i++)
                    EDS.App.Current.Dispatcher.Invoke((Action)delegate
                    {
                        _HarnessRules.Add(new vmHarnessRule(this, App.RuleVM._ruleList[i]._rule));
                    });

                GetSelected();
                EDS.App.Current.Dispatcher.Invoke((Action)delegate
                {
                    harnessScanSelectionReadyBool = true;
                    ToolsScanBool = true;
                });

            });
        }

        public ICommand SelectSpecificRulesCommand
        {
            get { return new RelayCommand<string>(selectSpecificRules); }
        }
        private void selectSpecificRules(string selectType)
        {
            switch (selectType)
            {
                case "all":
                    foreach (vmHarnessRule rule in _HarnessRules)
                        rule.SelectedRuleBool = true;
                    break;
                case "none":
                    foreach (vmHarnessRule rule in _HarnessRules)
                        rule.SelectedRuleBool = false;
                    break;
                case "rules":
                    foreach (vmHarnessRule rule in _HarnessRules)
                        if (rule.RuleTypeDesc == "Rule")
                            rule.SelectedRuleBool = true;
                    break;
                case "consideration":
                    foreach (vmHarnessRule rule in _HarnessRules)
                        if (rule.RuleTypeDesc == "Consideration")
                            rule.SelectedRuleBool = true;
                    break;
                case "requirement":
                    foreach (vmHarnessRule rule in _HarnessRules)
                        if (rule.RuleTypeDesc == "Requirement")
                            rule.SelectedRuleBool = true;
                    break;
            }
        }

        private RelayCommand _StartScanPromptCommand;
        public ICommand StartScanPromptCommand
        {
            get
            {
                if (_StartScanPromptCommand == null) _StartScanPromptCommand = new RelayCommand(param => startScanPrompt(), param => { return (true); });

                return _StartScanPromptCommand;
            }
        }
        private void startScanPrompt()
        {
            App.HarnessScanVM.gridDisplayBool = false;
            startScanPromptBool = true;
        }
        private RelayCommand _CancelScanPromptCommand;
        public ICommand CancelScanPromptCommand
        {
            get
            {
                if (_CancelScanPromptCommand == null) _CancelScanPromptCommand = new RelayCommand(param => cancelScanPrompt(), param => { return (true); });

                return _CancelScanPromptCommand;
            }
        }
        private void cancelScanPrompt()
        {
            App.HarnessScanVM.gridDisplayBool = true;
            startScanPromptBool = false;
        }

        private RelayCommand _StartScanCommand;
        public ICommand StartScanCommand
        {
            get
            {
                if (_StartScanCommand == null) _StartScanCommand = new RelayCommand(param => startScan(), param => { return (true); });

                return _StartScanCommand;
            }
        }
        private void startScan()
        {
            SearchString = "";

            vmProgram program = new vmProgram(Program.CreateProgram("-1", ProgramName, "jmill592"), App.ProgramsVM.Programs);
            program.Harnesses.Add(this);
            App.ProgramsVM.Programs.Add(program);

            HarnessCheckBool = true;
            GetStatistics();

            App.HarnessScanVM.reset();

            App.ProgramsVM.SelectedProgram = program;
            selectHarness();
            App.MainVM.SelectedTabIndex = 0;
        }

        #region Fix All...

        private int currIndexHarness;

        private vmHarnessRule _SelectedHarnessRule;
        public vmHarnessRule SelectedHarnessRule
        {
            get { return _SelectedHarnessRule; }
            set
            {
                if (this._SelectedHarnessRule != value)
                {
                    this._SelectedHarnessRule = value;
                    this.RaisePropertyChangedEvent("SelectedHarnessRule");
                }
            }
        }

        private RelayCommand _FixAllRulesCommand;
        public ICommand FixAllRulesCommand
        {
            get
            {
                if (_FixAllRulesCommand == null) _FixAllRulesCommand = new RelayCommand(param => fixAllRulesCommand(), param => { return (true); });

                return _FixAllRulesCommand;
            }
        }
        private void fixAllRulesCommand()
        {
            currIndexHarness = 0;

            Utilities.PopupHelper.TabIndex(2, this);
            Utilities.PopupHelper.SetVisibility(true);

            for (currIndexHarness = currIndexHarness; currIndexHarness < _HarnessRules.Count; currIndexHarness++)
                if (_HarnessRules[currIndexHarness].GoodCount != 1)
                {
                    SelectedHarnessRule = _HarnessRules[currIndexHarness];
                    currIndexHarness++;
                    break;
                }
        }

        private RelayCommand _CompleteHarnessRepairCommand;
        public ICommand CompleteHarnessRepairCommand
        {
            get
            {
                if (_CompleteHarnessRepairCommand == null) _CompleteHarnessRepairCommand = new RelayCommand(param => completeHarnessRepair(), param => { return (true); });

                return _CompleteHarnessRepairCommand;
            }
        }
        private void completeHarnessRepair()
        {
            SelectedHarnessRule.save();

            if (GoodCount == TotalCount)
                Utilities.PopupHelper.SetVisibility(false);

            for (currIndexHarness = currIndexHarness; currIndexHarness < _HarnessRules.Count; currIndexHarness++)
            {
                if (_HarnessRules[currIndexHarness].GoodCount != 1 && _HarnessRules[currIndexHarness].SelectedRuleBool)
                {
                    SelectedHarnessRule = _HarnessRules[currIndexHarness];
                    currIndexHarness++;
                    break;
                }
            }
        }

        private RelayCommand _CancelHarnessFixCommand;
        public ICommand CancelHarnessFixCommand
        {
            get
            {
                if (_CancelHarnessFixCommand == null) _CancelHarnessFixCommand = new RelayCommand(param => cancelharnessFix(), param => { return (true); });

                return _CancelHarnessFixCommand;
            }
        }
        private void cancelharnessFix()
        {
            Cancel();

            Utilities.PopupHelper.SetVisibility(false);
        }

        #endregion

        #endregion

        #region Methods

        public override void Save()
        {
            HarnessDescProp.Save();
            RevisionProp.Save();
            OwnerProp.Save();

            SaveProps();
        }
        public override void Cancel()
        {
            HarnessDescProp.Save();
            RevisionProp.Save();
            OwnerProp.Save();

            SaveProps();
        }
        public override void Remove()
        {
            _harnesses.Remove(this);
        }
        public override void Revert()
        {
            HarnessDescProp.Save();
            RevisionProp.Save();
            OwnerProp.Save();

            SaveProps();
        }

        private void SaveProps()
        {
            HarnessDesc = HarnessDescProp.Saved;
            Revision = RevisionProp.Saved;
            Owner = OwnerProp.Saved;
        }

        public void checkTools(string toolString)
        {
            string[] tools = toolString.Split(',');

            foreach (string tool in tools)
            {
                string[] toolInfo = tool.Split(':');

                switch (toolInfo[0])
                {
                    case "PMI":
                        PMIBool = true;
                        break;
                    case "DTSync":
                        DTSyncBool = true;
                        break;
                    case "FFA2":
                        FFA2Bool = true;
                        break;
                    case "Renaming":
                        RenamingBool = true;
                        break;
                    case "Coupon":
                        CouponBool = true;
                        break;
                    default:
                        break;
                }
            }
        }
        private void checkToolBools()
        {
            if (PMIBool && DTSyncBool && FFA2Bool && RenamingBool && CouponBool)
                toolsScanCompleteTerniary = 0;
            else if (PMIBool || DTSyncBool || FFA2Bool || RenamingBool || CouponBool)
                toolsScanCompleteTerniary = 1;
            else
                toolsScanCompleteTerniary = 2;
        }
        public void resetToolBools()
        {
            PMIBool = false;
            DTSyncBool = false;
            FFA2Bool = false;
            RenamingBool = false;
            CouponBool = false;
        }

        public void GetSelected()
        {
            SelectedRuleCount = 0;

            foreach (vmHarnessRule rule in _HarnessRules)
                if (rule.SelectedRuleBool)
                    SelectedRuleCount++;
        }

        public override void GetStatistics()
        {
            GoodCount = 0;
            WarningCount = 0;
            ErrorCount = 0;

            TotalCount = 0;

            foreach (vmHarnessRule rule in _HarnessRules)
                if (rule.SelectedRuleBool)
                {
                    rule.GetStatistics();

                    GoodCount += rule.GoodCount;
                    WarningCount += rule.WarningCount;
                    ErrorCount += rule.ErrorCount;

                    TotalCount += rule.TotalCount;
                }
        }

        #endregion

        #region IDataErrorInfo Members

        string IDataErrorInfo.Error { get { return (_harness as IDataErrorInfo).Error; } }

        string IDataErrorInfo.this[string propertyName]
        {
            get
            {
                string error = null;
                error = (_harness as IDataErrorInfo)[propertyName];
                return error;
            }
        }
        #endregion
    }
}