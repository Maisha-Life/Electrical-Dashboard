﻿using System;
using System.Collections.ObjectModel;

using EDS.Models.Scans.Harness;

namespace EDS.ViewModels.ModelsVM.Scans.Harness
{
    public class vmBranch : vmBase
    {
        private readonly Branch _branch;
        private readonly ObservableCollection<vmBranch> _branches;

        public vmBranch(Branch branch, ObservableCollection<vmBranch> branches) 
        {
            _branch = branch ?? throw new ArgumentNullException("branch");
            _branches = branches ?? throw new ArgumentNullException("branches");
        }

        #region Data Binds

        private string _BranchName;
        public string BranchName
        {
            get
            {
                if (_BranchName == null)
                    _BranchName = _branch.BrancheName;

                return _BranchName;
            }
            set
            {
                _BranchName = value;
                _branch.BrancheName = _BranchName;
                this.RaisePropertyChangedEvent("BranchName");
            }
        }

        private string _Length;
        public string Length
        {
            get
            {
                if (_Length == null)
                    _Length = _branch.Length;

                return _Length;
            }
            set
            {
                _Length = value;
                _branch.Length = _Length;
                this.RaisePropertyChangedEvent("Length");
            }
        }

        private string _Diameter;
        public string Diameter
        {
            get
            {
                if (_Diameter == null)
                    _Diameter = _branch.Diameter;

                return _Diameter;
            }
            set
            {
                _Diameter = value;
                _branch.Diameter = _Diameter;
                this.RaisePropertyChangedEvent("Diameter");
            }
        }

        #endregion

        #region Commands



        #endregion

        #region Methods

        

        #endregion
    }
}
