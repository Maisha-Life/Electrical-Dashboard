﻿using System;
using System.Collections.ObjectModel;

using EDS.Models.Scans.Harness;

namespace EDS.ViewModels.ModelsVM.Scans.Harness
{
    public class vmDevice : vmBase
    {
        private readonly Device _device;
        private readonly ObservableCollection<vmDevice> _devices;

        public vmDevice(Device device, ObservableCollection<vmDevice> devices)
        {
            _device = device ?? throw new ArgumentNullException("device");
            _devices = devices ?? throw new ArgumentNullException("devices");
        }

        #region Data Binds

        private string _PartNumber;
        public string PartNumber
        {
            get
            {
                if (_PartNumber == null)
                    _PartNumber = _device.PartNumber;

                return _PartNumber;
            }
            set
            {
                _PartNumber = value;
                _device.PartNumber = _PartNumber;
                this.RaisePropertyChangedEvent("PartNumber");
            }
        }

        private string _PartName;
        public string PartName
        {
            get
            {
                if (_PartName == null)
                    _PartName = _device.PartName;

                return _PartName;
            }
            set
            {
                _PartName = value;
                _device.PartName = _PartName;
                this.RaisePropertyChangedEvent("PartName");
            }
        }

        private string _DeviceType;
        public string DeviceType
        {
            get
            {
                if (_DeviceType == null)
                    _DeviceType = _device.DeviceType;

                return _DeviceType;
            }
            set
            {
                _DeviceType = value;
                _device.DeviceType = _DeviceType;
                this.RaisePropertyChangedEvent("DeviceType");
            }
        }

        #endregion

        #region Commands



        #endregion

        #region Methods



        #endregion
    }
}
