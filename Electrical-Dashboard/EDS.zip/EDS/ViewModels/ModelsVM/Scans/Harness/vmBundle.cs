﻿using System;
using System.Collections.ObjectModel;

using EDS.Models.Scans.Harness;

namespace EDS.ViewModels.ModelsVM.Scans.Harness
{
    public class vmBundle : vmBase
    {
        private readonly Bundle _bundle;
        private readonly ObservableCollection<vmBundle> _bundles;

        public vmBundle(Bundle bundle, ObservableCollection<vmBundle> bundles)
        {
            _bundle = bundle ?? throw new ArgumentNullException("bundle");
            _bundles = bundles ?? throw new ArgumentNullException("bundles");
        }

        #region Data Binds

        private string _BundleName;
        public string BundleName
        {
            get
            {
                if (_BundleName == null)
                    _BundleName = _bundle.BundleName;

                return _BundleName;
            }
            set
            {
                _BundleName = value;
                _bundle.BundleName = _BundleName;
                this.RaisePropertyChangedEvent("BundleName");
            }
        }

        private ObservableCollection<vmBranch> _Branches;
        public ObservableCollection<vmBranch> Branches
        {
            get { return _Branches ?? (_Branches = new ObservableCollection<vmBranch>()); }
            set
            {
                if (this._Branches != value)
                {
                    this._Branches = value;
                    this.RaisePropertyChangedEvent("Branches");
                }
            }
        }

        #endregion

        #region Commands



        #endregion

        #region Methods



        #endregion
    }
}
