﻿using System;
using System.Collections.ObjectModel;

using EDS.Models;

namespace EDS.ViewModels.ModelsVM
{
    public class vmRuleBase : vmBase
    {
        public readonly Rule _rule;
        //public readonly ObservableCollection<vmRuleBase> _ruleList;

        public vmRuleBase(Rule rule)
        {
            this._rule = rule ?? throw new ArgumentNullException("rule");
        }

        #region Data Binds

        protected string _RuleTypeDesc;
        public virtual string RuleTypeDesc
        {
            get
            {
                if (_RuleTypeDesc == null)
                    _RuleTypeDesc = _rule.RuleTypeDesc;

                return _RuleTypeDesc;
            }
            set
            {
                _RuleTypeDesc = value;
                _rule.RuleTypeDesc = _RuleTypeDesc;
                this.RaisePropertyChangedEvent("RuleTypeDesc");
            }
        }

        protected string _DesignRule;
        public virtual string DesignRule
        {
            get
            {
                if (_DesignRule == null)
                    _DesignRule = _rule.DesignRule;

                return _DesignRule;
            }
            set
            {
                _DesignRule = value;
                _rule.DesignRule = _DesignRule;
                this.RaisePropertyChangedEvent("DesignRule");
            }
        }

        protected string _LegacyIDDesc;
        public virtual string LegacyIDDesc
        {
            get
            {
                if (_LegacyIDDesc == null)
                    _LegacyIDDesc = _rule.LegacyIDDesc;

                return _LegacyIDDesc;
            }
            set
            {
                _LegacyIDDesc = value;
                _rule.LegacyIDDesc = _LegacyIDDesc;
                this.RaisePropertyChangedEvent("LegacyDesc");
            }
        }

        protected string _RuleName;
        public virtual string RuleName
        {
            get
            {
                if (_RuleName == null)
                    _RuleName = _rule.RuleName;

                return _RuleName;
            }
            set
            {
                _RuleName = value;
                _rule.RuleName = _RuleName;
                this.RaisePropertyChangedEvent("RuleName");
            }
        }

        protected string _RuleDesc;
        public virtual string RuleDesc
        {
            get
            {
                if (_RuleDesc == null)
                    _RuleDesc = _rule.RuleDesc;

                return _RuleDesc;
            }
            set
            {
                _RuleDesc = value;
                _rule.RuleDesc = _RuleDesc;
                this.RaisePropertyChangedEvent("RuleDesc");
            }
        }
                     
        #endregion
    }
}
