﻿using System;
using System.Data.Sql;
using System.Data.SqlClient;
using EDS.Models;
using EDS.ViewModels;
using EDS.ViewModels.ModelsVM;
using EDS.ViewModels.ViewsVM;

namespace SQLQueryVM
{
    public class vmAddQueryItem : vmQueryItem
    {
        public vmAddQueryItem(vmBase Parent, vmBase Object, vmQuery Queries)
            : base(Parent, Object, Queries)
        {
            Type = "Add";

            ObjectType = _object.GetType().Name;
            Description = UpdateDescription();
        }
        public vmAddQueryItem(vmBase Object, vmQuery Queries)
            : base(Object, Queries)
        {
            Type = "Add";

            ObjectType = _object.GetType().Name;
            Description = UpdateDescription();
        }

        #region Methods

        public override void RevertQuery()
        {
            switch (ObjectType)
            {
                case "vmRuleAll":
                    ((vmRuleAll)_object).Remove();
                    break;
                case "vmQuestion":
                    ((vmQuestion)_object).Remove();
                    break;
                case "vmConstraint":
                    ((vmRuleConstraint)_object).Remove();
                    break;
                case "vmParameter":
                    ((vmParameter)_object).Remove();
                    break;
                case "vmGroup:":
                    ((vmGroup)_object).Remove();
                    break;
                case "vmRuleConstruct":
                    ((vmRuleConstruct)_object).Remove();
                    break;
                case "vmProgram":
                    ((vmProgram)_object).Remove();
                    break;
                case "vmHarness":
                    ((vmHarness)_object).Remove();
                    break;
                case "vmHarnessCheckResult":
                    ((vmHarnessCheckResult)_object).Remove();
                    break;
                case "vmHarnessRule":
                    ((vmHarnessRule)_object).Remove();
                    break;
            }
        }

        public void CreateQueryNExecute(SqlConnection con)
        {
            SqlCommand cmd = null;
            SqlDataReader reader = null;

            switch (ObjectType)
            {
                case "vmRuleAll":
                    vmRuleAll rule = (vmRuleAll)_object;

                    query = "insert into Rules(Id_RuleType, DesignRule, RuleName, RuleDesc, Id_Status, ConstraintBool, CheckBool, RepairBool, Id_CheckType, Id_RepairType, Author) " +
                                                "values(" + returnID(rule.RuleTypeDesc, "Id_Type", "Type", con) + ", @DR, @RN, @RD, 2,0,0,0,12,12, @A)";

                    cmd = new SqlCommand(query, con);

                    cmd.Parameters.AddWithValue("@DR", rule.DesignRule);
                    cmd.Parameters.AddWithValue("@RN", rule.RuleName);
                    cmd.Parameters.AddWithValue("@RD", rule.RuleDesc);
                    cmd.Parameters.AddWithValue("@A", rule.Author);

                    cmd.ExecuteNonQuery();

                    //ensure that ID is there for sequential items
                    cmd = new SqlCommand("SELECT @@IDENTITY;", con);
                    rule._rule.Id_Rule = cmd.ExecuteScalar().ToString();

                    if (!String.IsNullOrEmpty(rule.LegacyIDDesc))
                        addLegacyID(rule.LegacyIDDesc, rule._rule.Id_Rule, con);

                    break;
                case "vmQuestion":
                    vmQuestion question = (vmQuestion)_object;

                    query = "insert into Questions(QuestionDesc, AnswerDesc, Id_QuestionType, Id_Rule) values ('" +
                                                   question.QuestionDesc + "','" +
                                                   question.AnswerDesc + "'," +
                                                   returnID(question._question.QuestionTypeDesc, "Id_Type", "Type", con) + "," +
                                                   question._rule._rule.Id_Rule + ")";
                    executeQuery(con);

                    cmd = new SqlCommand("SELECT @@IDENTITY;", con);
                    string id_question = cmd.ExecuteScalar().ToString();

                    question._question.Id_Question = id_question;

                    break;
                case "vmConstraint":
                    vmRuleConstraint constraint = (vmRuleConstraint)_object;

                    query = "insert into Constructs (Id_ConstructType, ConstructDesc) values (" +
                                                     returnID(constraint.ConstructTypeDesc, "Id_Type", "Type", con) + ",'" +
                                                     constraint.ConstructDesc + "')";
                    executeQuery(con);

                    cmd = new SqlCommand("SELECT @@IDENTITY;", con);
                    constraint._construct.Id_Construct = cmd.ExecuteScalar().ToString();

                    query = "insert into RuleConstants(Id_Construct, Id_Rule) values (" +
                                                   constraint._construct.Id_Construct + "," +
                                                   constraint._rule._rule.Id_Rule + ")";
                    executeQuery(con);
                    break;
                case "vmParameter":
                    vmParameter parameter = (vmParameter)_object;

                    query = "insert into RuleConstants(Id_Construct, Id_Rule) values (" +
                                                   parameter._parameter.Id_Construct + "," +
                                                   parameter._rule._rule.Id_Rule + ")";

                    executeQuery(con);
                    break;
                case "vmGroup":
                    vmGroup group = (vmGroup)_object;

                    query = "insert into RuleCategories(Id_Group, Id_Rule) values (" +
                                                   group._group.Id_Group + "," +
                                                   group._rule._rule.Id_Rule + ")";

                    executeQuery(con);
                    break;
                case "vmRuleConstruct":
                    vmRuleConstruct ruleConstruct = (vmRuleConstruct)_object;
                    //search for constant, if does not exist then add it
                    string id_constant = "";

                    query = "select Id_RuleConstant from RuleConstants where Id_Construct=" + ruleConstruct.RuleConstruct._construct.Id_Construct + " and Id_Rule=" + ruleConstruct._rule._rule.Id_Rule;

                    cmd = new SqlCommand(query, con);
                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                        id_constant = reader[0].ToString();

                    if (id_constant == "")
                    {
                        query = "insert into RuleConstants(Id_Construct, Id_Rule) values (" +
                                                       ruleConstruct.RuleConstruct._construct.Id_Construct + "," +
                                                       ruleConstruct._rule._rule.Id_Rule + ")";

                        executeQuery(con);

                        cmd = new SqlCommand("SELECT @@IDENTITY;", con);
                        id_constant = cmd.ExecuteScalar().ToString();
                    }

                    query = "insert into RuleConstructs(Id_RuleConstant, Id_MethodType, ConstructOrder) values(" +
                                                        id_constant + "," +
                                                        returnID(ruleConstruct.MethodTypeDesc, "Id_Type", "Type", con) + "," +
                                                        ruleConstruct.RuleConstructOrder + ")";

                    executeQuery(con);

                    cmd = new SqlCommand("SELECT @@IDENTITY;", con);
                    ruleConstruct._ruleConstruct.Id_RuleConstruct = cmd.ExecuteScalar().ToString();


                    break;
                case "vmProgram":
                    vmProgram program = (vmProgram)_object;

                    query = "insert into Programs(ProgramDesc, Id_User) values('" +
                                                  program.ProgramDesc + "'," +
                                                  returnID(program.Owner, "Id_User", "User", con) + ")";

                    executeQuery(con);

                    cmd = new SqlCommand("SELECT @@IDENTITY;", con);
                    program._program.Id_Program = cmd.ExecuteScalar().ToString();
                    break;
                case "vmHarness":
                    vmHarness harness = (vmHarness)_object;

                    string id_harnessGroup = "";
                    //check if harnessGroup exists (for multiple revisions but same desc)...
                    query = "select Id_HarnessGroup from HarnessGroup where HarnessDesc='" + harness.HarnessDesc + "'";

                    cmd = new SqlCommand(query, con);
                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                        id_harnessGroup = reader[0].ToString();
                    //if it does not exists then do add it
                    if (id_harnessGroup == "")
                    {
                        query = "insert into HarnessGroup(Id_Program, HarnessDesc) values(" +
                                                          harness._program._program.Id_Program + ",'" +
                                                          harness.HarnessDesc + "')";

                        executeQuery(con);

                        cmd = new SqlCommand("SELECT @@IDENTITY;", con);
                        id_harnessGroup = cmd.ExecuteScalar().ToString();
                    }

                    query = "insert into Harnesses(Id_HarnessGroup, Revision, Id_User, ToolsScanBool, PMIBool, DTSyncBool, FFA2Bool, RenamingBool, HarnessCheckBool) values(" +
                                                   id_harnessGroup + "," +
                                                   harness.Revision + "," +
                                                   returnID(harness.Owner, "Id_User", "User", con) + "," +
                                                   returnInt(harness.ToolsScanBool.ToString()) + "," +
                                                   returnInt(harness.PMIBool.ToString()) + "," +
                                                   returnInt(harness.DTSyncBool.ToString()) + "," +
                                                   returnInt(harness.FFA2Bool.ToString()) + "," +
                                                   returnInt(harness.RenamingBool.ToString()) + "," +
                                                   returnInt(harness.HarnessCheckBool.ToString()) + ")";
                    executeQuery(con);

                    cmd = new SqlCommand("SELECT @@IDENTITY;", con);
                    harness._harness.Id_Harness = cmd.ExecuteScalar().ToString();
                    break;
                case "vmHarnessCheckResult":
                    vmHarnessCheckResult harnessCheckResult = (vmHarnessCheckResult)_object;

                    query = "insert into HarnessCheckResults(Id_HarnessRule, HarnessCheckResultDesc, Id_Status) values(" +
                                                             harnessCheckResult._harnessrule._rule.Id_Rule + "," +
                                                             harnessCheckResult._harnessCheckResult.Id_Harness + ",'" +
                                                             harnessCheckResult.HarnessCheckResultDesc + "'," +
                                                             harnessCheckResult.Id_Status + ")";
                    executeQuery(con);

                    cmd = new SqlCommand("SELECT @@IDENTITY;", con);
                    harnessCheckResult._harnessCheckResult.Id_HarnessCheckResult = cmd.ExecuteScalar().ToString();
                    break;
                case "vmHarnessRule":
                    break;
            }

            //cmd.Dispose();
        }
        private void addLegacyID(string legacyIDDesc, string ruleID, SqlConnection con)
        {
            SqlCommand cmd = new SqlCommand("insert into LegacyID(LegacyIDDesc, Id_Rule) values('" + legacyIDDesc + "'," + ruleID + ")", con);
            cmd.ExecuteNonQuery();
        }

        #endregion
    }
}