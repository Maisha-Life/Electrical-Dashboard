﻿using System.Data.Sql;
using System.Data.SqlClient;
using EDS.Models;
using EDS.ViewModels;
using EDS.ViewModels.ModelsVM;
using EDS.ViewModels.ViewsVM;


namespace SQLQueryVM
{
    public class vmEditQueryItem : vmQueryItem
    {
        public vmEditQueryItem(vmBase Object, vmQuery Queries)
            : base(Object, Queries)
        {
            Type = "Edit";

            ObjectType = _object.GetType().Name;
            Description = UpdateDescription();
        }

        public vmEditQueryItem(vmBase Parent, vmBase Object, vmQuery Queries)
            : base(Parent, Object, Queries)
        {
            Type = "Edit";

            ObjectType = _object.GetType().Name;
            Description = UpdateDescription();
        }

        #region Methods

        public override void RevertQuery()
        {
            switch (ObjectType)
            {
                case "vmRuleAll":
                    ((vmRuleAll)_object).Revert();
                    break;
                case "vmQuestion":
                    ((vmQuestion)_object).Revert();
                    break;
                case "vmConstraint":
                    ((vmRuleConstraint)_object).Revert();
                    break;
                case "vmRuleConstruct":
                    ((vmRuleConstruct)_object).Revert();
                    break;
                case "vmProgram":
                    ((vmProgram)_object).Revert();
                    break;
                case "vmHarness":
                    ((vmHarness)_object).Revert();
                    break;
                case "vmHarnessCheckResult":
                    ((vmHarnessCheckResult)_object).Revert();
                    break;
            }
        }

        public void CreateQueryNExecute(SqlConnection con)
        {
            SqlDataReader reader = null;

            switch (ObjectType)
            {
                case "vmRuleAll":
                    #region vmRule Edit Query
                    vmRuleAll rule = ((vmRuleAll)_object);

                    query = "update Rules set " +
                            "Id_RuleType=" + returnID(rule.RuleTypeDesc, "Id_Type", "Type", con) +
                            ", DesignRule=@DR, RuleName=@RN, RuleDesc=@RD, Author=@A, Id_Status=" + rule.Id_Status +
                            ", ConstraintBool=" + returnInt(rule.ConstraintBool) +
                            ", CheckBool=" + returnInt(rule.CheckBool) +
                            ", RepairBool=" + returnInt(rule.RepairBool) +
                            ", Id_CheckType=" + returnID(rule.CheckTypeDesc, "Id_Type", "Type", con) +
                            ", Id_RepairType=" + returnID(rule.RepairTypeDesc, "Id_Type", "Type", con) +
                            " where Id_Rule=" + rule._rule.Id_Rule;

                    cmd = new SqlCommand(query, con);

                    cmd.Parameters.AddWithValue("@DR", rule.DesignRule);
                    cmd.Parameters.AddWithValue("@RN", rule.RuleName);
                    cmd.Parameters.AddWithValue("@RD", rule.RuleDesc);
                    cmd.Parameters.AddWithValue("@A", rule.Author);

                    cmd.ExecuteNonQuery();

                    rule.Dispose();

                    return;
                    #endregion
                    break;
                case "vmQuestion":
                    #region vmQuestion Edit Query
                    vmQuestion question = ((vmQuestion)_object);

                    query = "update Questions set " +
                            "QuestionDesc='" + question.QuestionDesc +
                            "', AnswerDesc='" + question.AnswerDesc +
                            "' where Id_Question=" + question._question.Id_Question;

                    question.Dispose();
                    #endregion
                    break;
                case "vmConstraint":
                    #region vmConstraint Edit Query
                    vmRuleConstraint constraint = ((vmRuleConstraint)_object);

                    query = "update Constructs set " +
                            "ConstructDesc='" + constraint.ConstructDesc +
                            "' where Id_Construct=" + constraint._construct.Id_Construct;

                    constraint.Dispose();
                    #endregion                   
                    break;              
                case "vmRuleConstruct":
                    #region vmRuleConstruct Edit Query
                    vmRuleConstruct ruleConstruct = ((vmRuleConstruct)_object);

                    string id_constant = "";

                    query = "select Id_RuleConstant from RuleConstants where Id_Construct=" + ruleConstruct.RuleConstruct._construct.Id_Construct + " and Id_Rule=" + ruleConstruct._rule._rule.Id_Rule;

                    cmd = new SqlCommand(query, con);
                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                        id_constant = reader[0].ToString();

                    if (id_constant == "")
                    {
                        query = "insert into RuleConstants(Id_Construct, Id_Rule) values (" +
                                                       ruleConstruct.RuleConstruct._construct.Id_Construct + "," +
                                                       ruleConstruct._rule._rule.Id_Rule + ")";

                        executeQuery(con);

                        cmd = new SqlCommand("SELECT @@IDENTITY;", con);
                        id_constant = cmd.ExecuteScalar().ToString();
                    }

                    query = "update RuleConstructs set " +
                            "Id_RuleConstant=" + id_constant +
                            ", Id_MethodType=" + returnID(ruleConstruct.MethodTypeDesc, "Id_Type", "Type", con) +
                            ", ConstructOrder=" + ruleConstruct.RuleConstructOrder +
                            " where Id_RuleConstruct=" + ruleConstruct._ruleConstruct.Id_RuleConstruct; 

                    ruleConstruct.Dispose();
                    #endregion
                    break;
                case "vmProgram":
                    #region vmProgram Edit Query
                    vmProgram program = ((vmProgram)_object);

                    query = "update Programs set " +
                            "ProgramDesc='" + program.ProgramDesc +
                            "', Id_User=" + returnID(program.Owner, "Id_User", "User", con) +
                            " where Id_Program=" + program._program.Id_Program;

                    program.Dispose();
                    #endregion
                    break;
                case "vmHarness":
                    #region vmHarness Edit Query
                    vmHarness harness = ((vmHarness)_object);

                    query = "update HarnessGroup set" +
                            " HarnessDesc='" + harness.HarnessDesc +
                            "' where Id_HarnessGroup=" + harness._harness.Id_HarnessGroup;

                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();

                    query = "update Harnesses set" +
                            " Revision='" + harness.Revision +
                            "', Id_User=" + returnID(harness.Owner, "Id_User", "User", con) +
                            ", ToolsScanBool=" + returnInt(harness.ToolsScanBool.ToString()) +
                            ", PMIBool=" + returnInt(harness.PMIBool.ToString()) +
                            ", DTSyncBool=" + returnInt(harness.DTSyncBool.ToString()) +
                            ", FFA2Bool=" + returnInt(harness.FFA2Bool.ToString()) +
                            ", RenamingBool=" + returnInt(harness.RenamingBool.ToString()) +
                            ", HarnessCheckBool=" + returnInt(harness.HarnessCheckBool.ToString()) +
                            " where Id_Harness=" + harness._harness.Id_Harness;

                    harness.Dispose();
                    #endregion
                    break;
                case "vmHarnessCheckResult":
                    #region vmHarnessCheckResult Edit Query
                    vmHarnessCheckResult harnessCheckResult = ((vmHarnessCheckResult)_object);

                    query = "update HarnessCheckResults set " +
                            "HarnessCheckResultDesc='" + harnessCheckResult.HarnessCheckResultDesc +
                            "' Id_Status=" + harnessCheckResult.Id_Status +
                            " where Id_HarnessCheckResult=" + harnessCheckResult._harnessCheckResult.Id_HarnessCheckResult;

                    harnessCheckResult.Dispose();
                    #endregion
                    break;
            }
            executeQuery(con);
        }

        #endregion
    }
}
