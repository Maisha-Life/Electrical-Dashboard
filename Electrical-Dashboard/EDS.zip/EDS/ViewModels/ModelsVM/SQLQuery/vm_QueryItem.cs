﻿using System;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Input;

using EDS.ViewModels;
using EDS.ViewModels.ModelsVM;
using EDS.ViewModels.ViewsVM;

using MVVM.Utilities;

namespace SQLQueryVM
{
    public class vmQueryItem : vmBase
    {
        protected readonly vmQuery _queries;

        protected readonly vmBase _parent;
        protected readonly vmBase _object;

        #region Constructor

        public vmQueryItem(vmBase Object, vmQuery Queries)
        {
            _queries = Queries;

            _object = Object;
        }
        public vmQueryItem(vmBase Parent, vmBase Object, vmQuery Queries)
        {
            _queries = Queries;

            _parent = Parent;
            _object = Object;
        }

        #endregion

        #region Data Binds

        protected string ObjectType { get; set; }
        protected string query { get; set; }
        protected SqlCommand cmd { get; set; }

        private string _Description;
        public string Description
        {
            get { return _Description; }
            set
            {
                if (this._Description != value)
                {
                    this._Description = value;
                    this.RaisePropertyChangedEvent("Description");
                }
            }
        }

        private string m_Type;
        public string Type
        {
            get { return m_Type; }
            set
            {
                if (this.m_Type != value)
                {
                    this.m_Type = value;
                    this.RaisePropertyChangedEvent("Type");
                }
            }
        }

        #endregion

        #region Commands

        private RelayCommand _RemoveCommand;
        public ICommand RemoveCommand
        {
            get
            {
                if (_RemoveCommand == null) _RemoveCommand = new RelayCommand(param => Remove(), param => { return (true); });

                return _RemoveCommand;
            }
        }
        public override void Remove()
        {
            RevertQuery();

            _queries.Remove(this);
        }

        #endregion

        #region Methods
        
        protected string UpdateDescription()
        {
            string descriptEDS = @"EDS\";
            string descriptRule = @"Rule\";

            switch (ObjectType)
            {
                case "vmRuleAll":
                    return (descriptRule + ((vmRuleAll)_object).DesignRule);
                case "vmQuestion":
                    return (descriptRule + ((vmQuestion)_object)._rule.DesignRule) + @"\question";
                case "vmConstraint":
                    return (descriptRule + ((vmRuleConstraint)_object)._rule.DesignRule) + @"\" + ((vmRuleConstraint)_object).ConstructDesc;
                case "vmParameter":
                    return (descriptRule + ((vmParameter)_object)._rule.DesignRule) + @"\" + ((vmParameter)_object).ConstructDesc;
                case "vmGroup":
                    return (descriptRule + ((vmGroup)_object)._rule.DesignRule) + @"\" + ((vmGroup)_object).GroupName;
                case "vmRuleConstruct":
                    return (descriptRule + ((vmRuleConstruct)_object)._rule.DesignRule) + @"\" + ((vmRuleConstruct)_object).RuleConstruct.ConstructDesc;
                case "vmProgram":
                    return (descriptEDS + ((vmProgram)_object).ProgramDesc);
                case "vmHarness":
                    return (descriptEDS + ((vmHarness)_object).HarnessDesc);
                case "vmHarnessCheckResult":
                    return (descriptEDS + ((vmHarnessCheckResult)_object).HarnessCheckResultDesc);
                case "vmHarnessRule":
                    return (descriptEDS + ((vmHarnessRule)_object).DesignRule);
            }
            return "";
        }

        public virtual void RevertQuery()
        {
        }

        protected int returnID(string matchID, string uniqueID, string table, SqlConnection con)
        {
            string query = "select " + uniqueID + " from " + table + "s where " + table +"Desc='" + matchID + "'";
            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();

            reader.Read();

            int id = Convert.ToInt32(reader[0]);

            reader.Close();

            return id;
        }
        protected int returnInt(string value)
        {
            if (value.ToUpper() == "TRUE")
                return 1;
            else
                return 0;
        }

        protected void executeQuery(SqlConnection con)
        {
            cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
        }

        #endregion
    }
}
