﻿using System.Data.Sql;
using System.Data.SqlClient;
using EDS.ViewModels;
using EDS.ViewModels.ModelsVM;
using EDS.ViewModels.ViewsVM;

namespace SQLQueryVM
{
    public class vmRemoveQueryItem : vmQueryItem
    {
        public vmRemoveQueryItem(vmBase Object, vmQuery Queries)
            : base(Object, Queries)
        {
            Type = "Remove";

            ObjectType = _object.GetType().Name;
            Description = UpdateDescription();

        }

        public vmRemoveQueryItem(vmBase Parent, vmBase Object, vmQuery Queries)
            : base(Parent, Object, Queries)
        {
            Type = "Remove";

            ObjectType = _object.GetType().Name;
            Description = UpdateDescription();
        }

        #region Methods

        public override void RevertQuery()
        {
            switch (ObjectType)
            {
                case "vmRuleAll":
                    ((vmRuleAll)_object)._ruleList.Add((vmRuleAll)_object);
                    break;
                case "vmQuestion":
                    ((vmQuestion)_object)._questionList.Add((vmQuestion)_object);
                    break;
                case "vmConstraint":
                    ((vmRuleConstraint)_object)._constructs.Add((vmRuleConstraint)_object);
                    break;
                case "vmParameter":
                    ((vmParameter)_object).RevertRemove();
                    break;
                case "vmGroup":
                    ((vmGroup)_object).RevertRemove();
                    break;
                case "vmRuleConstruct":
                    ((vmRuleConstruct)_object)._constructs.Add((vmRuleConstruct)_object);
                    break;
                case "vmProgram":
                    ((vmProgram)_object)._programs.Add((vmProgram)_object);
                    break;
                case "vmHarness":
                    ((vmHarness)_object)._harnesses.Add((vmHarness)_object);
                    break;
                case "vmHarnessCheckResult":
                    ((vmHarnessCheckResult)_object)._checks.Add((vmHarnessCheckResult)_object);
                    break;
            }
        }

        public void CreateQueryNExecute(SqlConnection con)
        {
            switch (ObjectType)
            {
                case "vmRuleAll":
                    query = "delete from Rules where Id_Rule=" + ((vmRuleAll)_object)._rule.Id_Rule;
                    break;
                case "vmQuestion":
                    query = "delete from Questions where Id_Question=" + ((vmQuestion)_object)._question.Id_Question;
                    break;
                case "vmConstraint":
                    query = "delete from RuleConstants where Id_Construct=" + ((vmRuleConstraint)_object)._construct.Id_Construct + "and Id_Rule=" + ((vmRuleConstraint)_object)._rule._rule.Id_Rule;
                    break;
                case "vmParameter":
                    vmParameter parameter = (vmParameter)_object;

                    string id_construct = "";

                    //check if it exists already...
                    query = "select Id_Construct from Constructs where ConstructDesc='" + parameter.ConstructDesc + "'";

                    cmd = new SqlCommand(query, con);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                        id_construct = reader[0].ToString();

                    query = "delete from RuleConstants where Id_Construct=" + id_construct + " and Id_Rule=" + parameter._rule._rule.Id_Rule;
                    break;
                case "vmGroup":
                    query = "delete from RuleCategories where Id_Group=" + ((vmGroup)_object)._group.Id_Group + " and Id_Rule=" + ((vmGroup)_object)._rule._rule.Id_Rule;
                    break;
                case "vmRuleConstruct":
                    query = "delete from RuleConstructs where Id_RuleConstruct=" + ((vmRuleConstruct)_object)._ruleConstruct.Id_RuleConstruct;
                    break;
                case "vmProgram":
                    query = "delete from Programs where Id_Program=" + ((vmProgram)_object)._program.Id_Program;
                    break;
                case "vmHarness":
                    query = "delete from Harnesses where Id_Harness=" + ((vmHarness)_object)._harness.Id_Harness;
                    break;
                case "vmHarnessCheckResult":
                    query = "delete from HarnessCheckResults where Id_HarnessCheckResult=" + ((vmHarnessCheckResult)_object)._harnessCheckResult.Id_HarnessCheckResult;
                    break;
            }

            executeQuery(con);
        }

        #endregion
    }
}
