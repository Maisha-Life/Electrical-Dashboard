﻿using EDS.Models;
using EDS.Utilities;
using MVVM.Utilities;
using SQLQueryVM;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;
using System.Windows.Input;

namespace EDS.ViewModels.ModelsVM
{
    public class vmRuleAll : vmRuleBase, IDataErrorInfo
    {
        public ObservableCollection<vmRuleBase> _ruleList;
        public Queue<vmQueryItem> potentialChanges = new Queue<vmQueryItem>();
        //should only have one but testing for now, if its new then do this otherwise only do base...
        public vmRuleAll(Rule rule, ObservableCollection<vmRuleBase> ruleList, bool stateBool) : base(rule)
        {
            if (stateBool)
                App.RuleVM.RuleData.populateParameters(this);

            _ruleList = ruleList ?? throw new ArgumentNullException("rulelist");

            initializeConstructsCollections();
        }

        #region Data Binds

        private bool _QuestionBool;
        public bool QuestionBool
        {
            get { return _QuestionBool; }
            set
            {
                if (this._QuestionBool != value)
                {
                    this._QuestionBool = value;
                    this.RaisePropertyChangedEvent("QuestionBool");
                }
            }
        }

        private ThreeNOne _RuleTypeDescProp;
        public ThreeNOne RuleTypeDescProp
        {
            get
            {
                if (_RuleTypeDescProp == null)
                    _RuleTypeDescProp = new ThreeNOne(_rule.RuleTypeDesc);

                return _RuleTypeDescProp;
            }
            set
            {
                if (_RuleTypeDescProp != value)
                {
                    _RuleTypeDescProp = value;
                    _rule.RuleTypeDesc = _RuleTypeDescProp.Changed;
                    this.RaisePropertyChangedEvent("RuleTypeDescProp");
                }
            }
        }
        public override string RuleTypeDesc
        {
            get { return RuleTypeDescProp.Changed; }
            set
            {
                if (this._RuleTypeDescProp.Changed != value)
                    this._RuleTypeDescProp.Changed = value;

                _rule.RuleTypeDesc = value;
                this.RaisePropertyChangedEvent("RuleTypeDesc");
            }
        }

        private ThreeNOne _DesignRuleProp;
        public ThreeNOne DesignRuleProp
        {
            get
            {
                if (_DesignRuleProp == null)
                    _DesignRuleProp = new ThreeNOne(_rule.DesignRule);

                return _DesignRuleProp;
            }
            set
            {
                if (_DesignRuleProp != value)
                {
                    _DesignRuleProp = value;
                    _rule.DesignRule = _DesignRuleProp.Changed;
                    this.RaisePropertyChangedEvent("DesignRuleProp");
                }
            }
        }
        public override string DesignRule
        {
            get { return DesignRuleProp.Changed; }
            set
            {
                if (this._DesignRuleProp.Changed != value)
                    this._DesignRuleProp.Changed = value;

                _rule.DesignRule = value;
                this.RaisePropertyChangedEvent("DesignRule");
            }
        }

        private ThreeNOne _LegacyIDDescProp;
        public ThreeNOne LegacyIDDescProp
        {
            get
            {
                if (_LegacyIDDescProp == null)
                    _LegacyIDDescProp = new ThreeNOne(_rule.LegacyIDDesc);

                return _LegacyIDDescProp;
            }
            set
            {
                if (_LegacyIDDescProp != value)
                {
                    _LegacyIDDescProp = value;
                    _rule.LegacyIDDesc = _LegacyIDDescProp.Changed;
                    this.RaisePropertyChangedEvent("LegacyIDDescProp");
                }
            }
        }
        public override string LegacyIDDesc
        {
            get { return LegacyIDDescProp.Changed; }
            set
            {
                if (this._LegacyIDDescProp.Changed != value)
                    this._LegacyIDDescProp.Changed = value;

                _rule.LegacyIDDesc = value;
                this.RaisePropertyChangedEvent("LegacyIDDesc");
            }
        }

        private ThreeNOne _RuleNameProp;
        public ThreeNOne RuleNameProp
        {
            get
            {
                if (_RuleNameProp == null)
                    _RuleNameProp = new ThreeNOne(_rule.RuleName);

                return _RuleNameProp;
            }
            set
            {
                if (_RuleNameProp != value)
                {
                    _RuleNameProp = value;
                    _rule.RuleName = _RuleNameProp.Changed;
                    this.RaisePropertyChangedEvent("RuleNameProp");
                }
            }
        }
        public override string RuleName
        {
            get { return RuleNameProp.Changed; }
            set
            {
                if (this._RuleNameProp.Changed != value)
                    this._RuleNameProp.Changed = value;

                _rule.RuleName = value;
                this.RaisePropertyChangedEvent("RuleName");
            }
        }

        private ThreeNOne _RuleDescProp;
        public ThreeNOne RuleDescProp
        {
            get
            {
                if (_RuleDescProp == null)
                    _RuleDescProp = new ThreeNOne(_rule.RuleDesc);

                return _RuleDescProp;
            }
            set
            {
                if (_RuleDescProp != value)
                {
                    _RuleDescProp = value;
                    _rule.RuleDesc = _RuleDescProp.Changed;
                    this.RaisePropertyChangedEvent("RuleDescProp");
                }
            }
        }
        public override string RuleDesc
        {
            get { return RuleDescProp.Changed; }
            set
            {
                if (this._RuleDescProp.Changed != value)
                    this._RuleDescProp.Changed = value;

                _rule.RuleDesc = value;
                this.RaisePropertyChangedEvent("RuleDesc");
            }
        }
        
        private int _Id_Status;
        public int Id_Status
        {
            get
            {
               _Id_Status = _rule.Id_Status;

                return _Id_Status;
            }
            set
            {
                _Id_Status = value;
                _rule.Id_Status = _Id_Status;
                this.RaisePropertyChangedEvent("Id_Status");
            }
        }

        private ThreeNOne _ConstraintBoolProp;
        public ThreeNOne ConstraintBoolProp
        {
            get
            {
                if (_ConstraintBoolProp == null)
                    _ConstraintBoolProp = new ThreeNOne(_rule.ConstraintBool.ToString());

                return _ConstraintBoolProp;
            }
            set
            {
                if (_ConstraintBoolProp != value)
                {
                    _ConstraintBoolProp = value;
                    this.RaisePropertyChangedEvent("ConstraintBoolProp");
                }
            }
        }
        public string ConstraintBool
        {
            get { return ConstraintBoolProp.Changed; }
            set
            {
                if (this._ConstraintBoolProp.Changed != value)
                    this._ConstraintBoolProp.Changed = value;

                _rule.ConstraintBool = (value.ToUpper() == "TRUE" ? true : false);
                this.RaisePropertyChangedEvent("ConstraintBool");
            }
        }

        private ThreeNOne _CheckBoolProp;
        public ThreeNOne CheckBoolProp
        {
            get
            {
                if (_CheckBoolProp == null)
                    _CheckBoolProp = new ThreeNOne(_rule.CheckBool.ToString());

                return _CheckBoolProp;
            }
            set
            {
                if (_CheckBoolProp != value)
                {
                    _CheckBoolProp = value;
                    this.RaisePropertyChangedEvent("CheckBoolProp");
                }
            }
        }
        public string CheckBool
        {
            get { return CheckBoolProp.Changed; }
            set
            {
                if (this._CheckBoolProp.Changed != value)
                    this._CheckBoolProp.Changed = value;

                _rule.CheckBool = (value.ToUpper() == "TRUE" ? true : false);
                this.RaisePropertyChangedEvent("CheckBool");
            }
        }

        private ThreeNOne _RepairBoolProp;
        public ThreeNOne RepairBoolProp
        {
            get
            {
                if (_RepairBoolProp == null)
                    _RepairBoolProp = new ThreeNOne(_rule.RepairBool.ToString());

                return _RepairBoolProp;
            }
            set
            {
                if (_RepairBoolProp != value)
                {
                    _RepairBoolProp = value;
                    this.RaisePropertyChangedEvent("RepairBoolProp");
                }
            }
        }
        public string RepairBool
        {
            get { return RepairBoolProp.Changed; }
            set
            {
                if (this._RepairBoolProp.Changed != value)
                    this._RepairBoolProp.Changed = value;

                _rule.RepairBool = (value.ToUpper() == "TRUE" ? true : false);
                this.RaisePropertyChangedEvent("RepairBool");
            }
        }

        private ThreeNOne _CheckTypeDescProp;
        public ThreeNOne CheckTypeDescProp
        {
            get
            {
                if (_CheckTypeDescProp == null)
                    _CheckTypeDescProp = new ThreeNOne(_rule.CheckTypeDesc);

                return _CheckTypeDescProp;
            }
            set
            {
                if (_CheckTypeDescProp != value)
                {
                    _CheckTypeDescProp = value;
                    this.RaisePropertyChangedEvent("CheckTypeDescProp");
                }
            }
        }
        public string CheckTypeDesc
        {
            get { return CheckTypeDescProp.Changed; }
            set
            {
                if (this._CheckTypeDescProp.Changed != value)
                    this._CheckTypeDescProp.Changed = value;

                if (value.ToUpper() == "TRUE")
                    _rule.CheckTypeDesc = "Automatic";
                else if (value.ToUpper() == "FALSE")
                    _rule.CheckTypeDesc = "Manual";
                else
                    _rule.CheckTypeDesc = value;

                this.RaisePropertyChangedEvent("CheckTypeDesc");
            }
        }

        private ThreeNOne _RepairTypeDescProp;
        public ThreeNOne RepairTypeDescProp
        {
            get
            {
                if (_RepairTypeDescProp == null)
                    _RepairTypeDescProp = new ThreeNOne(_rule.RepairTypeDesc);

                return _RepairTypeDescProp;
            }
            set
            {
                if (_RepairTypeDescProp != value)
                {
                    _RepairTypeDescProp = value;
                    this.RaisePropertyChangedEvent("RepairTypeDescProp");
                }
            }
        }
        public string RepairTypeDesc
        {
            get { return RepairTypeDescProp.Changed; }
            set
            {
                if (this._RepairTypeDescProp.Changed != value)
                    this._RepairTypeDescProp.Changed = value;

                if (value.ToUpper() == "TRUE")
                    _rule.RepairTypeDesc = "Automated";
                else if (value.ToUpper() == "FALSE")
                    _rule.RepairTypeDesc = "Manual";
                else
                    _rule.RepairTypeDesc = value;

                this.RaisePropertyChangedEvent("RepairTypeDesc");
            }
        }

        private ThreeNOne _AuthorProp;
        public ThreeNOne AuthorProp
        {
            get
            {
                if (_AuthorProp == null)
                    _AuthorProp = new ThreeNOne(_rule.Author);

                return _AuthorProp;
            }
            set
            {
                if (_AuthorProp != value)
                {
                    _AuthorProp = value;
                    _rule.Author = _AuthorProp.Changed;
                    this.RaisePropertyChangedEvent("AuthorProp");
                }
            }
        }
        public string Author
        {
            get { return AuthorProp.Changed; }
            set
            {
                if (this._AuthorProp.Changed != value)
                    this._AuthorProp.Changed = value;

                _rule.Author = value;
                this.RaisePropertyChangedEvent("Author");
            }
        }        
        //All questions here filtered by the type. See how efficient or inefficient that is ???(does it load only what is used or does it still load everything...)???
        private ObservableCollection<vmQuestion> _questions;
        public ObservableCollection<vmQuestion> questions
        {
            get { return _questions ?? (_questions = new ObservableCollection<vmQuestion>()); }
            set
            {
                if (this._questions != value)
                {
                    this._questions = value;
                    this.RaisePropertyChangedEvent("questions");
                }
            }
        }
        //All constants here filtered by the type maybe...(just parameters)...
        private ObservableCollection<vmConstructBase> _constants;
        public ObservableCollection<vmConstructBase> constants
        {
            get { return _constants ?? (_constants = new ObservableCollection<vmConstructBase>()); }
            set
            {
                if (this._constants != value)
                {
                    this._constants = value;
                    this.RaisePropertyChangedEvent("constants");
                }
            }
        }
        private ObservableCollection<vmGroup> _groups;
        public ObservableCollection<vmGroup> groups
        {
            get { return _groups ?? (_groups = new ObservableCollection<vmGroup>()); }
            set
            {
                if (this._groups != value)
                {
                    this._groups = value;
                    this.RaisePropertyChangedEvent("constants");
                }
            }
        }

        //constraints seperate for a seperate list...
        private ObservableCollection<vmConstructBase> _constraints;
        public ObservableCollection<vmConstructBase> constraints
        {
            get { return _constraints ?? (_constraints = new ObservableCollection<vmConstructBase>()); }
            set
            {
                if (this._constraints != value)
                {
                    this._constraints = value;
                    this.RaisePropertyChangedEvent("constraints");
                }
            }
        }
        //rule constructs...two seperate lists will order them by order though...

        public readonly ObservableCollection<vmRuleConstruct> _checkConstructs = new ObservableCollection<vmRuleConstruct>();
        public ICollectionView checkConstructs { get; set; }
        public readonly ObservableCollection<vmRuleConstruct> _repairConstructs = new ObservableCollection<vmRuleConstruct>();
        public ICollectionView repairConstructs { get; set; }

        #endregion

        #region Commands

        private RelayCommand _AddRuleCommand;
        public ICommand AddRuleCommand
        {
            get
            {
                if (_AddRuleCommand == null) _AddRuleCommand = new RelayCommand(param => addRule(), param => { return (_rule.IsValid); });

                return _AddRuleCommand;
            }
        }
        private void addRule()
        {
            Save();

            PopupHelper.SetVisibility(false);

            _ruleList.Add(this);

            App.MainQuery.queries.Add(new vmAddQueryItem(this, App.MainQuery));

            while (potentialChanges.Count > 0)
                App.MainQuery.queries.Add(potentialChanges.Dequeue());
        }

        private RelayCommand _EditRuleCommand;
        public ICommand EditRuleCommand
        {
            get
            {
                if (_EditRuleCommand == null) _EditRuleCommand = new RelayCommand(param => editRule(), param => { return (true); });

                return _EditRuleCommand;
            }
        }
        private void editRule()
        {
            EditBool = true;

            PopupHelper.TabIndex(8, this);
            PopupHelper.SetVisibility(true);
        }

        private RelayCommand _SaveRuleCommand;
        public ICommand SaveRuleCommand
        {
            get
            {
                if (_SaveRuleCommand == null) _SaveRuleCommand = new RelayCommand(param => saveRule(), param => { return (_rule.IsValid); });

                return _SaveRuleCommand;
            }
        }
        private void saveRule()
        {
            Save();

            PopupHelper.SetVisibility(false);            

            while (potentialChanges.Count > 0)
                App.MainQuery.queries.Add(potentialChanges.Dequeue());
        }

        private RelayCommand _CancelRuleCommand;
        public ICommand CancelRuleCommand
        {
            get
            {
                if (_CancelRuleCommand == null) _CancelRuleCommand = new RelayCommand(param => cancelRule(), param => { return (true); });

                return _CancelRuleCommand;
            }
        }
        private void cancelRule()
        {
            Cancel();

            PopupHelper.SetVisibility(false);
        }

        private RelayCommand _RemoveRuleCommand;
        public ICommand RemoveRuleCommand
        {
            get
            {
                if (_RemoveRuleCommand == null) _RemoveRuleCommand = new RelayCommand(param => removeRule(), param => { return (true); });

                return _RemoveRuleCommand;
            }
        }
        private void removeRule()
        {
            if (Views.Popups.WarningMessageBox.ShowBox(RuleName, "Rules List") == System.Windows.Forms.DialogResult.Yes)
            {
                App.MainQuery.queries.Add(new vmRemoveQueryItem(this, App.MainQuery));

                Remove();
            }          
        }

        private RelayCommand _AddConstraintCommand;
        public ICommand AddConstraintCommand
        {
            get
            {
                if (_AddConstraintCommand == null) _AddConstraintCommand = new RelayCommand(param => addConstraint(), param => { return (true); });

                return _AddConstraintCommand;
            }
        }
        private void addConstraint()
        {
            vmRuleConstraint newConstraint = new vmRuleConstraint(Construct.CreateConstruct("Constraint", "new constraint..."), constraints, this);
            newConstraint.EditBool = true;

            constraints.Add(newConstraint);

            potentialChanges.Enqueue(new vmAddQueryItem(newConstraint, App.MainQuery));
        }

        public ICommand AddConstructCommand
        {
            get { return new RelayCommand<string>(addConstruct); }
        }
        private void addConstruct(string value)
        {
            vmRuleConstruct construct = null;

            switch (value)
            {
                case "check_Logic":
                    construct = new vmRuleConstruct(RuleConstruct.CreateRuleConstruct((_checkConstructs.Count + 1).ToString(), "Check"), _checkConstructs, App.RuleVM.RuleData.LogicList, this);
                    break;
                case "check_Constraint":
                    construct = new vmRuleConstruct(RuleConstruct.CreateRuleConstruct((_checkConstructs.Count + 1).ToString(), "Check"), _checkConstructs, constraints, this);
                    break;
                case "check_Parameter":
                    construct = new vmRuleConstruct(RuleConstruct.CreateRuleConstruct((_checkConstructs.Count + 1).ToString(), "Check"), _checkConstructs, App.RuleVM.RuleData.ParametersList, this);
                    break;
                case "repair_Logic":
                    construct = new vmRuleConstruct(RuleConstruct.CreateRuleConstruct((_repairConstructs.Count + 1).ToString(), "Repair"), _repairConstructs, App.RuleVM.RuleData.LogicList, this);
                    break;
                case "repair_Constraint":
                    construct = new vmRuleConstruct(RuleConstruct.CreateRuleConstruct((_repairConstructs.Count + 1).ToString(), "Repair"), _repairConstructs, constraints, this);
                    break;
                case "repair_Parameter":
                    construct = new vmRuleConstruct(RuleConstruct.CreateRuleConstruct((_repairConstructs.Count + 1).ToString(), "Repair"), _repairConstructs, App.RuleVM.RuleData.ParametersList, this);
                    break;
            }

            construct.EditBool = true;
            construct.IsExpanded = true;

            construct.setDefaultConstruct(construct.constructRoot.ElementAt(0));

            if (value.Contains("check"))
                _checkConstructs.Add(construct);
            else
                _repairConstructs.Add(construct);

            refreshList();

            potentialChanges.Enqueue(new vmAddQueryItem(construct, App.MainQuery));
        }

        private RelayCommand _AddRuleQuestionCommand;
        public ICommand AddRuleQuestionCommand
        {
            get
            {
                if (_AddRuleQuestionCommand == null) _AddRuleQuestionCommand = new RelayCommand(param => addRuleQuestion(), param => { return (true); });

                return _AddRuleQuestionCommand;
            }
        }
        private void addRuleQuestion()
        {
            vmQuestion newQuestion = new vmQuestion(Question.CreateQuestion("question", "RuleQuestion"), questions, this);

            questions.Add(newQuestion);

            potentialChanges.Enqueue(new vmAddQueryItem(newQuestion, App.MainQuery));
        }

        private RelayCommand _RaiseBaseQuestionCommand;
        public ICommand RaiseBaseQuestionCommand
        {
            get
            {
                if (_RaiseBaseQuestionCommand == null) _RaiseBaseQuestionCommand = new RelayCommand(param => raiseBaseQuestion(), param => { return (true); });

                return _RaiseBaseQuestionCommand;
            }
        }
        private void raiseBaseQuestion()
        {
            vmQuestion newQuestion = new vmQuestion(Question.CreateQuestion("What is this rule?", "RuleQuestion"), questions, this);

            questions.Add(newQuestion);

            potentialChanges.Enqueue(new vmAddQueryItem(newQuestion, App.MainQuery));

            saveRule();
        }

        #endregion

        #region Methods

        public override void Save() 
        {
            RuleTypeDescProp.Save();
            DesignRuleProp.Save();
            LegacyIDDescProp.Save();
            RuleNameProp.Save();
            RuleDescProp.Save();
            ConstraintBoolProp.Save();
            CheckBoolProp.Save();
            RepairBoolProp.Save();
            CheckTypeDescProp.Save();
            RepairTypeDescProp.Save();

            SaveProps();

            foreach (vmQuestion question in questions)
                question.Save();
            foreach (vmConstructBase constant in constants)
                constant.Save(this);
            foreach (vmGroup group in groups)
                group.Save(this);
            foreach (vmRuleConstruct construct in checkConstructs)
                construct.Save();
            foreach (vmRuleConstruct construct in repairConstructs)
                construct.Save();

            CheckStatus();

            if (RuleTypeDescProp.ChangedBool || DesignRuleProp.ChangedBool || LegacyIDDescProp.ChangedBool || RuleNameProp.ChangedBool || RuleDescProp.ChangedBool ||
                ConstraintBoolProp.ChangedBool || CheckBoolProp.ChangedBool || RepairBoolProp.ChangedBool || CheckTypeDescProp.ChangedBool || RepairTypeDescProp.ChangedBool)
                App.MainQuery.queries.Add(new vmEditQueryItem(this, App.MainQuery));
        }
        public override void Cancel() 
        {
            RuleTypeDescProp.Cancel();
            DesignRuleProp.Cancel();
            LegacyIDDescProp.Cancel();
            RuleNameProp.Cancel();
            RuleDescProp.Cancel();
            ConstraintBoolProp.Cancel();
            CheckBoolProp.Cancel();
            RepairBoolProp.Cancel();
            CheckTypeDescProp.Cancel();
            RepairTypeDescProp.Cancel();

            SaveProps();

            foreach (vmQuestion question in questions)
                question.Cancel();
            foreach (vmConstructBase constant in constants)
                constant.Cancel();
            foreach (vmGroup group in groups)
                group.Save(this);
            foreach (vmRuleConstruct construct in checkConstructs)
                construct.Cancel();
            foreach (vmRuleConstruct construct in repairConstructs)
                construct.Cancel();            

            CheckStatus();

            while (potentialChanges.Count > 0)
                potentialChanges.Dequeue().RevertQuery();
        }
        public override void Remove() 
        {
            _ruleList.Remove(this);
        }
        public override void Revert() 
        {
            RuleTypeDescProp.Default();
            DesignRuleProp.Default();
            LegacyIDDescProp.Default();
            RuleNameProp.Default();
            RuleDescProp.Default();
            ConstraintBoolProp.Default();
            CheckBoolProp.Default();
            RepairBoolProp.Default();
            CheckTypeDescProp.Default();
            RepairTypeDescProp.Default();

            SaveProps();

            foreach (vmQuestion question in questions)
                question.Revert();
            foreach (vmConstructBase constant in constants)
                constant.Revert();
            foreach (vmRuleConstruct construct in checkConstructs)
                construct.Revert();
            foreach (vmRuleConstruct construct in repairConstructs)
                construct.Revert();

            CheckStatus();
        }

        public void countStatus()
        {

        }

        private void SaveProps()
        {
            RuleTypeDesc = RuleTypeDescProp.Saved;
            DesignRule = DesignRuleProp.Saved;
            LegacyIDDesc = LegacyIDDescProp.Saved;
            RuleName = RuleNameProp.Saved;
            RuleDesc = RuleDescProp.Saved;

            ConstraintBool = ConstraintBoolProp.Saved;
            CheckBool = CheckBoolProp.Saved;
            RepairBool = RepairBoolProp.Saved;

            CheckTypeDesc = CheckTypeDescProp.Saved;
            RepairTypeDesc = RepairTypeDescProp.Saved;

            EditBool = false;
        }
        private void CheckStatus()
        {
            if (ConstraintBool.ToUpper() == "TRUE" && CheckBool.ToUpper() == "TRUE" && RepairBool.ToUpper() == "TRUE")
                Id_Status = 0;
            else if (ConstraintBool.ToUpper() == "FALSE" && CheckBool.ToUpper() == "FALSE" && RepairBool.ToUpper() == "FALSE")
                Id_Status = 2;
            else
                Id_Status = 1;

            QuestionBool = CheckQuestionsStatus();
        }
        public bool CheckQuestionsStatus()
        {
            foreach (vmQuestion question in questions)
                if (String.IsNullOrWhiteSpace(question.AnswerDesc))
                    return true;

            return false;
        }

        public void newRule()
        {
            foreach (vmConstructBase constraint in App.RuleVM.RuleData.ParametersList)
                constants.Add(new vmParameter(Construct.CreateConstruct(constraint.ConstructTypeDesc, constraint._construct.Id_Construct, constraint.ConstructDesc), constants, this, false));

            foreach (vmConstructBase constraint in App.RuleVM.RuleData.LogicList)
                constants.Add(new vmParameter(Construct.CreateConstruct(constraint.ConstructTypeDesc, constraint._construct.Id_Construct, constraint._construct.ConstructDesc), constants, this, false));
        }

        public void initializeConstructsCollections()
        {
            checkConstructs = CollectionViewSource.GetDefaultView(_checkConstructs);
            checkConstructs.SortDescriptions.Add(new SortDescription("RuleConstructOrder", ListSortDirection.Ascending));
            repairConstructs = CollectionViewSource.GetDefaultView(_repairConstructs);
            repairConstructs.SortDescriptions.Add(new SortDescription("RuleConstructOrder", ListSortDirection.Ascending));
        }
        public void refreshList()
        {
            checkConstructs.Refresh();
            repairConstructs.Refresh();
        }

        #endregion

        #region IDataErrorInfo Members

        string IDataErrorInfo.Error { get { return (_rule as IDataErrorInfo).Error; } }
        string IDataErrorInfo.this[string propertyName]
        {
            get
            {
                string error = null;
                error = (_rule as IDataErrorInfo)[propertyName];
                return error;
            }
        }

        #endregion
    }
}
