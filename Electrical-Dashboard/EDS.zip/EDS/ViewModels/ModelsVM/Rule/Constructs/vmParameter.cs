﻿using System;
using System.Collections.ObjectModel;

using MVVM.Utilities;
using EDS.Models;
using SQLQueryVM;

namespace EDS.ViewModels.ModelsVM
{
    public class vmParameter : vmConstructBase
    {
        public readonly Construct _parameter;

        public vmParameter(Construct parameter, ObservableCollection<vmConstructBase> constructs) : base(parameter, constructs)
        {
            _parameter = parameter ?? throw new ArgumentNullException("parameter");
        }
        public vmParameter(Construct parameter, ObservableCollection<vmConstructBase> constructs, bool selectedBool) : base(parameter, constructs)
        {
            _parameter = parameter ?? throw new ArgumentNullException("parameter");

            this.selectedBool = selectedBool;
        }
        public vmParameter(Construct parameter, ObservableCollection<vmConstructBase> constructs, vmRuleAll rule, bool selectedBool) : base(parameter, constructs, rule)
        {
            _parameter = parameter ?? throw new ArgumentNullException("parameter");
            this.selectedBool = selectedBool;
        }

        public bool selectedBool { get; set; }

        private ThreeNOne _SelectedBoolProp;
        public ThreeNOne SelectedBoolProp
        {
            get
            {
                if (_SelectedBoolProp == null)
                    _SelectedBoolProp = new ThreeNOne(selectedBool.ToString());

                return _SelectedBoolProp;
            }
            set
            {
                if (_SelectedBoolProp != value)
                {
                    _SelectedBoolProp = value;
                    this.RaisePropertyChangedEvent("SelectedBoolProp");
                }
            }
        }
        public string SelectedBool
        {
            get { return SelectedBoolProp.Changed; }
            set
            {
                if (this._SelectedBoolProp.Changed != value)
                    this._SelectedBoolProp.Changed = value;

                selectedBool = ( value.ToUpper() == "TRUE" ? true : false);
                this.RaisePropertyChangedEvent("SelectedBool");
            }
        }

        #region Methods
                
        public override void Save(vmRuleAll rule)
        {
            if (_rule == null)
                _rule = rule;

            SelectedBoolProp.Save();

            SaveProps();

            if (SelectedBoolProp.ChangedBool)
            {                                          
                if (SelectedBool.ToUpper() == "TRUE")
                    _rule.potentialChanges.Enqueue(new vmAddQueryItem(this, App.MainQuery));
                else
                    _rule.potentialChanges.Enqueue(new vmRemoveQueryItem(this, App.MainQuery));
            }
        }
        public override void Cancel()
        {
            SelectedBoolProp.Cancel();

            SaveProps();
        }
        public override void Remove() 
        {
            SelectedBool = "false";

            SelectedBoolProp.Save();

            SaveProps();
        }
        public override void Revert()
        {
            SelectedBoolProp.Default();

            SaveProps();
        }
        public void RevertRemove()
        {
            SelectedBool = "true";

            SelectedBoolProp.Save();

            SaveProps();
        }

        private void SaveProps()
        {
            SelectedBool = SelectedBoolProp.Saved;

            EditBool = false;
        }

        #endregion
    }
}