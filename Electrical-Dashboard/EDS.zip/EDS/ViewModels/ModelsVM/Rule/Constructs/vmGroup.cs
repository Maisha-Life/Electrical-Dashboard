﻿using System;
using System.Collections.ObjectModel;

using MVVM.Utilities;
using EDS.Models;
using SQLQueryVM;

namespace EDS.ViewModels.ModelsVM
{
    public class vmGroup : vmBase
    {
        public readonly Group _group;
        public vmRuleAll _rule;

        public vmGroup(Group group)
        {
            _group = group ?? throw new ArgumentNullException("group");
        }
        public vmGroup(Group group, bool selectedBool)
        {
            _group = group ?? throw new ArgumentNullException("group");

            this.selectedBool = selectedBool;
        }
        public vmGroup(Group group, vmRuleAll rule, bool selectedBool)
        {
            _group = group ?? throw new ArgumentNullException("group");

            _rule = rule ?? throw new ArgumentNullException("rule");

            this.selectedBool = selectedBool;
        }

        public bool selectedBool { get; set; }

        private ThreeNOne _SelectedBoolProp;
        public ThreeNOne SelectedBoolProp
        {
            get
            {
                if (_SelectedBoolProp == null)
                    _SelectedBoolProp = new ThreeNOne(selectedBool.ToString());

                return _SelectedBoolProp;
            }
            set
            {
                if (_SelectedBoolProp != value)
                {
                    _SelectedBoolProp = value;
                    this.RaisePropertyChangedEvent("SelectedBoolProp");
                }
            }
        }
        public string SelectedBool
        {
            get { return SelectedBoolProp.Changed; }
            set
            {
                if (this._SelectedBoolProp.Changed != value)
                    this._SelectedBoolProp.Changed = value;

                selectedBool = (value.ToUpper() == "TRUE" ? true : false);
                this.RaisePropertyChangedEvent("SelectedBool");
            }
        }

        private string _GroupType;
        public string GroupType
        {
            get
            {
                if (_GroupType == null)
                    _GroupType = _group.GroupType;

                return _GroupType;
            }
            set
            {
                _GroupType = value;
                _group.GroupType = _GroupType;
                this.RaisePropertyChangedEvent("GroupType");
            }
        }

        private string _GroupRank;
        public string GroupRank
        {
            get
            {
                if (_GroupRank == null)
                    _GroupRank = _group.GroupRank;

                return _GroupRank;
            }
            set
            {
                _GroupRank = value;
                _group.GroupRank = _GroupRank;
                this.RaisePropertyChangedEvent("GroupRank");
            }
        }

        private string _GroupName;
        public string GroupName
        {
            get
            {
                if (_GroupName == null)
                    _GroupName = _group.GroupName;

                return _GroupName;
            }
            set
            {
                _GroupName = value;
                _group.GroupName = _GroupName;
                this.RaisePropertyChangedEvent("GroupName");
            }
        }

        private string _GroupDescription;
        public string GroupDescription
        {
            get
            {
                if (_GroupDescription == null)
                    _GroupDescription = _group.GroupDescription;

                return _GroupDescription;
            }
            set
            {
                _GroupDescription = value;
                _group.GroupDescription = _GroupDescription;
                this.RaisePropertyChangedEvent("GroupDescription");
            }
        }
        
        #region Methods

        public void Save(vmRuleAll rule)
        {
            if (_rule == null)
                _rule = rule;

            SelectedBoolProp.Save();

            SaveProps();

            if (SelectedBoolProp.ChangedBool)
            {
                if (SelectedBool.ToUpper() == "TRUE")
                    _rule.potentialChanges.Enqueue(new vmAddQueryItem(this, App.MainQuery));
                else
                    _rule.potentialChanges.Enqueue(new vmRemoveQueryItem(this, App.MainQuery));
            }
        }
        public override void Cancel()
        {
            SelectedBoolProp.Cancel();

            SaveProps();
        }
        public override void Remove()
        {
            SelectedBool = "false";

            SelectedBoolProp.Save();

            SaveProps();
        }
        public override void Revert()
        {
            SelectedBoolProp.Default();

            SaveProps();
        }
        public void RevertRemove()
        {
            SelectedBool = "true";

            SelectedBoolProp.Save();

            SaveProps();
        }

        private void SaveProps()
        {
            SelectedBool = SelectedBoolProp.Saved;

            EditBool = false;
        }

        #endregion
    }
}
