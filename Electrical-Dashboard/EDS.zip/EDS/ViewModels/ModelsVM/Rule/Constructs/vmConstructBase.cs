﻿using System;
using System.Collections.ObjectModel;

using EDS.Models;

namespace EDS.ViewModels.ModelsVM
{
    public class vmConstructBase : vmBase
    {
        public Construct _construct { get; set; }

        public vmRuleAll _rule;

        public readonly ObservableCollection<vmConstructBase> _constructs;

        public vmConstructBase() { }
        public vmConstructBase(Construct construct, ObservableCollection<vmConstructBase> constructs)
        {
            _construct = construct ?? throw new ArgumentNullException("constraint");
            _constructs = constructs ?? throw new ArgumentNullException("constraints");
        }
        public vmConstructBase(Construct construct, ObservableCollection<vmConstructBase> constructs, vmRuleAll rule)
        {
            _construct = construct ?? throw new ArgumentNullException("constraint");
            _constructs = constructs ?? throw new ArgumentNullException("constraints");
            _rule = rule ?? throw new ArgumentNullException("rule");
        }       

        private string _ConstructDesc;
        public virtual string ConstructDesc
        {
            get
            {
                if (_ConstructDesc == null)
                    _ConstructDesc = _construct.ConstructDesc;

                return _ConstructDesc;
            }
            set
            {
                _ConstructDesc = value;
                _construct.ConstructDesc = _ConstructDesc;
                this.RaisePropertyChangedEvent("ConstructDesc");
            }
        }

        private string _ConstructTypeDesc;
        public string ConstructTypeDesc
        {
            get
            {
                if (_ConstructTypeDesc == null)
                    _ConstructTypeDesc = _construct.ConstructTypeDesc;

                return _ConstructTypeDesc;
            }
            set
            {
                _ConstructTypeDesc = value;
                _construct.ConstructTypeDesc = _ConstructTypeDesc;
                this.RaisePropertyChangedEvent("ConstructTypeDesc");
            }
        }

        #region Methods

        public virtual void Save(vmRuleAll rule) { }

        #endregion
    }
}
