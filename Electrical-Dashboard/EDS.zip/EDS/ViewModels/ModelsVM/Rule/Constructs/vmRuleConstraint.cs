﻿using System.Collections.ObjectModel;
using System.Windows.Input;

using EDS.Models;

using MVVM.Utilities;

using SQLQueryVM;


namespace EDS.ViewModels.ModelsVM
{
    public class vmRuleConstraint : vmConstructBase
    {
        public vmRuleConstraint(Construct construct, ObservableCollection<vmConstructBase> constructs, vmRuleAll rule) : base (construct, constructs, rule) { }

        #region Data Binds

        private ThreeNOne _ConstructDescProp;
        public ThreeNOne ConstructDescProp
        {
            get
            {
                if (_ConstructDescProp == null)
                    _ConstructDescProp = new ThreeNOne(_construct.ConstructDesc);

                return _ConstructDescProp;
            }
            set
            {
                if (_ConstructDescProp != value)
                {
                    _ConstructDescProp = value;
                    _construct.ConstructDesc = _ConstructDescProp.Changed;
                    this.RaisePropertyChangedEvent("ConstructDescProp");
                }
            }
        }
        public override string ConstructDesc
        {
            get { return ConstructDescProp.Changed; }
            set
            {
                if (this._ConstructDescProp.Changed != value)
                    this._ConstructDescProp.Changed = value;

                _construct.ConstructDesc = value;
                this.RaisePropertyChangedEvent("constructDesc");
            }
        }

        #endregion

        #region Commands

        private RelayCommand _SaveConstraintCommand;
        public ICommand SaveConstraintCommand
        {
            get
            {
                if (_SaveConstraintCommand == null) _SaveConstraintCommand = new RelayCommand(param => saveConstraint(), param => { return (true); });

                return _SaveConstraintCommand;
            }
        }
        private void saveConstraint()
        {
            Save();
        }

        private RelayCommand _CancelConstraintCommand;
        public ICommand CancelConstraintCommand
        {
            get
            {
                if (_CancelConstraintCommand == null) _CancelConstraintCommand = new RelayCommand(param => cancelConstraint(), param => { return (true); });

                return _CancelConstraintCommand;
            }
        }
        private void cancelConstraint()
        {
            Cancel();
        }
        //check if it is used in ruleConstructs in the rule before removing...
        private RelayCommand _RemoveConstraintCommand;
        public ICommand RemoveConstraintCommand
        {
            get
            {
                if (_RemoveConstraintCommand == null) _RemoveConstraintCommand = new RelayCommand(param => removeConstraint(), param => { return (true); });

                return _RemoveConstraintCommand;
            }
        }
        private void removeConstraint()
        {
            if (Views.Popups.WarningMessageBox.ShowBox(ConstructDesc, _rule.RuleName) == System.Windows.Forms.DialogResult.Yes)
            {
                _rule.potentialChanges.Enqueue(new vmRemoveQueryItem(this, App.MainQuery));

                Remove();
            }
        }

        #endregion

        #region Methods    

        public override void Save()
        {
            ConstructDescProp.Save();

            SaveProps();

            if (ConstructDescProp.ChangedBool)
                _rule.potentialChanges.Enqueue(new vmEditQueryItem(this, App.MainQuery));
        }
        public override void Save(vmRuleAll rule)
        {
            ConstructDescProp.Save();

            SaveProps();

            if (ConstructDescProp.ChangedBool)
                _rule.potentialChanges.Enqueue(new vmEditQueryItem(this, App.MainQuery));
        }
        public override void Cancel()
        {
            ConstructDescProp.Cancel();

            SaveProps();
        }
        public override void Remove()
        {
            _constructs.Remove(this);
        }
        public override void Revert()
        {
            ConstructDescProp.Default();

            SaveProps();
        }

        private void SaveProps()
        {
            ConstructDesc = ConstructDescProp.Saved;

            EditBool = false;
        }

        #endregion
    }
}
