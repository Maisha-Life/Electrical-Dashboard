﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Input;

using EDS.Models;
using MVVM.Utilities;
using SQLQueryVM;

namespace EDS.ViewModels.ModelsVM
{
    public class vmQuestion : vmBase
    {
        public vmRuleAll _rule;
        public readonly Question _question;
        public readonly ObservableCollection<vmQuestion> _questionList;

        public vmQuestion(Question question, ObservableCollection<vmQuestion> questionList, vmRuleAll rule)
        {
            _rule = rule ?? throw new ArgumentNullException("rule");
            _question = question ?? throw new ArgumentNullException("question");
            _questionList = questionList ?? throw new ArgumentNullException("questionList");
        }

        #region Data Binds

        private string _QuestionTypeDesc;
        public string QuestionTypeDesc
        {
            get
            {
                if (_QuestionTypeDesc == null)
                    _QuestionTypeDesc = _question.QuestionTypeDesc;

                return _QuestionTypeDesc;
            }
            set
            {
                _QuestionTypeDesc = value;
                _question.QuestionTypeDesc = _QuestionTypeDesc;
                this.RaisePropertyChangedEvent("QuestionTypeDesc");
            }
        }

        private ThreeNOne _QuestionDescProp;
        public ThreeNOne QuestionDescProp
        {
            get
            {
                if (_QuestionDescProp == null)
                    _QuestionDescProp = new ThreeNOne(_question.QuestionDesc);

                return _QuestionDescProp;
            }
            set
            {
                if (_QuestionDescProp != value)
                {
                    _QuestionDescProp = value;
                    _question.QuestionDesc = _QuestionDescProp.Changed;
                    this.RaisePropertyChangedEvent("QuestionDescProp");
                }
            }
        }
        public string QuestionDesc
        {
            get { return QuestionDescProp.Changed; }
            set
            {
                if (this._QuestionDescProp.Changed != value)
                    this._QuestionDescProp.Changed = value;

                _question.QuestionDesc = value;
                this.RaisePropertyChangedEvent("QuestionDesc");
            }
        }

        private ThreeNOne _AnswerDescProp;
        public ThreeNOne AnswerDescProp
        {
            get
            {
                if (_AnswerDescProp == null)
                    _AnswerDescProp = new ThreeNOne(_question.AnswerDesc);

                return _AnswerDescProp;
            }
            set
            {
                if (_AnswerDescProp != value)
                {
                    _AnswerDescProp = value;
                    _question.AnswerDesc = _AnswerDescProp.Changed;
                    this.RaisePropertyChangedEvent("AnswerDescProp");
                }
            }
        }
        public string AnswerDesc
        {
            get { return AnswerDescProp.Changed; }
            set
            {
                if (this._AnswerDescProp.Changed != value)
                    this._AnswerDescProp.Changed = value;

                _question.AnswerDesc = value;
                this.RaisePropertyChangedEvent("AnswerDesc");
            }
        }

        private bool _AnswerBool;
        public bool AnswerBool
        {
            get { return _AnswerBool; }
            set
            {
                if (this._AnswerBool != value)
                {
                    this._AnswerBool = value;
                    this.RaisePropertyChangedEvent("AnswerBool");
                }
            }
        }

        private bool _ChangeBool;
        public bool ChangeBool
        {
            get { return _ChangeBool; }
            set
            {
                if (this._ChangeBool != value)
                {
                    this._ChangeBool = value;
                    this.RaisePropertyChangedEvent("ChangeBool");
                }
            }
        }

        #endregion

        #region Commands

        private RelayCommand _RemoveQuestionCommand;
        public ICommand RemoveQuestionCommand
        {
            get
            {
                if (_RemoveQuestionCommand == null) _RemoveQuestionCommand = new RelayCommand(param => removeQuestion(), param => { return (true); });

                return _RemoveQuestionCommand;
            }
        }
        private void removeQuestion()
        {
            if (Views.Popups.WarningMessageBox.ShowBox(QuestionDesc, _rule.RuleName) == System.Windows.Forms.DialogResult.Yes)
            {
                _rule.potentialChanges.Enqueue(new vmRemoveQueryItem(this, App.MainQuery));

                Remove();
            }
        }

        private RelayCommand _CancelQuestionCommand;
        public ICommand CancelQuestionCommand
        {
            get
            {
                if (_CancelQuestionCommand == null) _CancelQuestionCommand = new RelayCommand(param => cancelQuestion(), param => { return (true); });

                return _CancelQuestionCommand;
            }
        }
        private void cancelQuestion()
        {
            Cancel();
        }

        #endregion

        #region Methods

        public override void Save()
        {
            QuestionDescProp.Save();
            AnswerDescProp.Save();

            SaveProps();

            if (QuestionDescProp.ChangedBool || AnswerDescProp.ChangedBool)
                _rule.potentialChanges.Enqueue(new vmEditQueryItem(this, App.MainQuery));
        }
        public override void Cancel()
        {
            QuestionDescProp.Cancel();
            AnswerDescProp.Cancel();
            
            SaveProps();
        }
        public override void Remove()
        {
            _questionList.Remove(this);
        }
        public override void Revert()
        {
            QuestionDescProp.Default();
            AnswerDescProp.Default();

            SaveProps();
        }

        private void SaveProps()
        {
            QuestionDesc = QuestionDescProp.Saved;
            AnswerDesc = AnswerDescProp.Saved;

            EditBool = false;
        }

        #endregion
    }
}