﻿using System.Collections.ObjectModel;
using System.Windows.Input;

using MVVM.Utilities;

using EDS.Models;
using System;
using SQLQueryVM;

namespace EDS.ViewModels.ModelsVM
{
    public class vmRuleConstruct : vmBase
    {
        public readonly vmRuleAll _rule;

        public readonly RuleConstruct _ruleConstruct;
        public readonly ObservableCollection<vmRuleConstruct> _constructs;

        public vmRuleConstruct(RuleConstruct ruleConstruct, ObservableCollection<vmRuleConstruct> constructs, ObservableCollection<vmConstructBase> constructRoot, vmRuleAll rule)
        {
            _ruleConstruct = ruleConstruct ?? throw new ArgumentNullException("construct");
            _rule = rule ?? throw new ArgumentNullException("rule");

            this._constructs = constructs;
            this.constructRoot = constructRoot;

            RuleConstructDefault = RuleConstruct;
            RuleConstruct = RuleConstructEdit;

            RuleConstructOrderProp.Save();

            SaveProps();
        }

        #region Data Binds

        public ObservableCollection<vmConstructBase> constructRoot { get; set; }

        public vmConstructBase RuleConstructDefault { get; set; }

        private vmConstructBase _RuleConstruct;
        public vmConstructBase RuleConstruct
        {
            get { return _RuleConstruct; }
            set
            {
                if (this._RuleConstruct != value)
                {
                    this._RuleConstruct = value;
                    this.RaisePropertyChangedEvent("RuleConstruct");
                }
            }
        }

        private vmConstructBase _RuleConstructEdit;
        public vmConstructBase RuleConstructEdit
        {
            get { return _RuleConstructEdit; }
            set
            {
                if (this._RuleConstructEdit != value)
                {
                    this._RuleConstructEdit = value;
                    this.RaisePropertyChangedEvent("RuleConstructEdit");
                }
            }
        }

        private ThreeNOne _RuleConstructOrderProp;
        public ThreeNOne RuleConstructOrderProp
        {
            get
            {
                if (_RuleConstructOrderProp == null)
                    _RuleConstructOrderProp = new ThreeNOne(_ruleConstruct.RuleConstructOrder);

                return _RuleConstructOrderProp;
            }
            set
            {
                if (_RuleConstructOrderProp != value)
                {
                    _RuleConstructOrderProp = value;
                    _ruleConstruct.RuleConstructOrder = _RuleConstructOrderProp.Changed;
                    this.RaisePropertyChangedEvent("RuleConstructOrderProp");
                }
            }
        }
        public string RuleConstructOrder
        {
            get { return RuleConstructOrderProp.Changed; }
            set
            {
                if (this._RuleConstructOrderProp.Changed != value)
                    this._RuleConstructOrderProp.Changed = value;

                _ruleConstruct.RuleConstructOrder = value;
                this.RaisePropertyChangedEvent("RuleConstructOrder");
            }
        }

        private string _MethodTypeDesc;
        public string MethodTypeDesc
        {
            get
            {
                if (_MethodTypeDesc == null)
                    _MethodTypeDesc = _ruleConstruct.MethodTypeDesc;

                return _MethodTypeDesc;
            }
            set
            {
                _MethodTypeDesc = value;
                _ruleConstruct.MethodTypeDesc = _MethodTypeDesc;
                this.RaisePropertyChangedEvent("MethodTypeDesc");
            }
        }

        private bool _IsExpanded;
        public bool IsExpanded
        {
            get { return _IsExpanded; }
            set
            {
                if (this._IsExpanded != value)
                {
                    if (EditBool == true)
                        value = true;

                    this._IsExpanded = value;
                    this.RaisePropertyChangedEvent("IsExpanded");
                }
            }
        }

        #endregion

        #region Commands

        private RelayCommand _IncreaseConstructOrderCommand;
        public ICommand IncreaseConstructOrderCommand
        {
            get
            {
                if (_IncreaseConstructOrderCommand == null) _IncreaseConstructOrderCommand = new RelayCommand(param => increaseOrder(), param => { return (RuleConstructOrder != (_constructs.Count).ToString()); });

                return _IncreaseConstructOrderCommand;
            }
        }
        private void increaseOrder()
        {            
            orderConstructs((Convert.ToInt32(RuleConstructOrder) + 1).ToString());
        }

        private RelayCommand _DecreaseConstructOrderCommand;
        public ICommand DecreaseConstructOrderCommand
        {
            get
            {
                if (_DecreaseConstructOrderCommand == null) _DecreaseConstructOrderCommand = new RelayCommand(param => descreaseOrder(), param => { return (RuleConstructOrder != "1"); });

                return _DecreaseConstructOrderCommand;
            }
        }
        private void descreaseOrder()
        {
            orderConstructs((Convert.ToInt32(RuleConstructOrder) - 1).ToString());
        }

        private RelayCommand _SaveConstructCommand;
        public ICommand SaveConstructCommand
        {
            get
            {
                if (_SaveConstructCommand == null) _SaveConstructCommand = new RelayCommand(param => saveConstruct(), param => { return (true); });

                return _SaveConstructCommand;
            }
        }
        private void saveConstruct()
        {
            Save();
        }

        private RelayCommand _CancelConstructCommand;
        public ICommand CancelConstructCommand
        {
            get
            {
                if (_CancelConstructCommand == null) _CancelConstructCommand = new RelayCommand(param => cancelConstruct(), param => { return (true); });

                return _CancelConstructCommand;
            }
        }
        private void cancelConstruct()
        {
            Cancel();
        }

        private RelayCommand _RemoveConstructCommand;
        public ICommand RemoveConstructCommand
        {
            get
            {
                if (_RemoveConstructCommand == null) _RemoveConstructCommand = new RelayCommand(param => removeConstruct(), param => { return (true); });

                return _RemoveConstructCommand;
            }
        }
        private void removeConstruct()
        {
            if (Views.Popups.WarningMessageBox.ShowBox(RuleConstructEdit.ConstructDesc, _rule.RuleName) == System.Windows.Forms.DialogResult.Yes)
            {
                _rule.potentialChanges.Enqueue(new vmRemoveQueryItem(this, App.MainQuery));

                Remove();
            }
        }

        #endregion

        #region Methods

        public override void Save()
        {
            RuleConstructDefault = RuleConstruct;
            RuleConstruct = RuleConstructEdit;

            RuleConstructOrderProp.Save();

            SaveProps();

            if (RuleConstructOrderProp.ChangedBool || RuleConstructDefault != RuleConstructEdit)
                _rule.potentialChanges.Enqueue(new vmEditQueryItem(this, App.MainQuery));
        }
        public override void Cancel()
        {
            RuleConstructEdit = RuleConstruct;

            RuleConstructOrderProp.Cancel();

            SaveProps();
        }
        public override void Remove()
        {
            _constructs.Remove(this);
        }
        public override void Revert()
        {
            RuleConstruct = RuleConstructDefault;

            RuleConstructOrderProp.Default();

            SaveProps();
        }

        private void SaveProps()
        {
            RuleConstructOrder = RuleConstructOrderProp.Saved;

            EditBool = false;
            IsExpanded = false;
        }

        public void setDefaultConstruct(vmConstructBase vmConstructBase)
        {
            RuleConstructDefault = vmConstructBase;
            RuleConstruct = vmConstructBase;
            RuleConstructEdit = vmConstructBase;
        }

        private void orderConstructs(string order)
        {
            foreach (vmRuleConstruct construct in _constructs)
                if (construct.RuleConstructOrder == order)
                {
                    construct.RuleConstructOrder = RuleConstructOrder;
                    construct.RuleConstructOrderProp.Save();
                    break;
                }

            RuleConstructOrder = order;

            _rule.refreshList();
        }

        #endregion
    }
}