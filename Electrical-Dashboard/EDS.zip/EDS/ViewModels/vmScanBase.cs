﻿using System.Windows;

namespace EDS.ViewModels
{
    public class vmScanBase : vmBase
    {
        #region Properties

        private int _GoodCount;
        public int GoodCount
        {
            get { return _GoodCount; }
            set
            {
                if (this._GoodCount != value)
                {
                    this._GoodCount = value;
                    this.RaisePropertyChangedEvent("GoodCount");
                }
            }
        }
        private int _WarningCount;
        public int WarningCount
        {
            get { return _WarningCount; }
            set
            {
                if (this._WarningCount != value)
                {
                    this._WarningCount = value;
                    this.RaisePropertyChangedEvent("WarningCount");
                }
            }
        }
        private int _ErrorCount;
        public int ErrorCount
        {
            get { return _ErrorCount; }
            set
            {
                if (this._ErrorCount != value)
                {
                    this._ErrorCount = value;
                    this.RaisePropertyChangedEvent("ErrorCount");
                }
            }
        }

        private int _TotalCount;
        public int TotalCount
        {
            get { return _TotalCount; }
            set
            {
                if (this._TotalCount != value)
                {
                    this._TotalCount = value;
                    this.RaisePropertyChangedEvent("TotalCount");
                }
            }
        }

        public int StatusID { get; set; }

        private Visibility _Visibility;
        public Visibility Visibility
        {
            get { return _Visibility; }
            set
            {
                if (this._Visibility != value)
                {
                    this._Visibility = value;
                    this.RaisePropertyChangedEvent("Visibility");
                }
            }
        }

        #endregion

        #region Methods

        public virtual void GetStatistics(){ }

        #endregion
    }
}
