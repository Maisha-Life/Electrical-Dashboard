﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDS.Models
{
    /// <summary>
    /// Not sure if I need id of rule and id of harness as I will be iterating through each harness where 
    /// id_harnessCheckResult.id_harness = id_harness then adding to the harness.checkedResults per rule
    /// </summary>
    public class HarnessCheckResult : BaseModel
    {
        public static HarnessCheckResult CreateHarnessCheckResults() { return new HarnessCheckResult(); }
        public static HarnessCheckResult CreateHarnessCheckResults(string id_harnessCheckResult, string harnessCheckDescription, string id_rule, string id_harness, string id_level) => new HarnessCheckResult()
        {
            Id_HarnessCheckResult = id_harnessCheckResult,

            HarnessCheckResultDesc = harnessCheckDescription,
            Id_Rule = id_rule,
            Id_Harness = id_harness,
            Id_Status = id_level
        };

        #region Properties
        
        public string Id_HarnessCheckResult { get; set; }

        public string HarnessCheckResultDesc { get; set; }
        public string Id_Status { get; set; }
        
        public string Id_Rule { get; set; }
        public string Id_Harness { get; set; }

        #endregion
    }
}
