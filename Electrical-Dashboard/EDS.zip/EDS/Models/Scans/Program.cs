﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDS.Models
{
    public class Program : BaseModel
    {
        public static Program CreateProgram() { return new Program(); }
        public static Program CreateProgram(string id_program, string programDesc, string owner) => new Program() { Id_Program = id_program, ProgramDesc = programDesc, Owner = owner };

        #region Properties

        public string Id_Program { get; set; }
        public string ProgramDesc { get; set; }
        public string Owner { get; set; }

        #endregion

        #region Validation

        protected override string[] ValidatedProperties
        {
            get
            {
                if (base.ValidatedProperties == null)
                    base.ValidatedProperties = new string[] { "ProgramDesc", "Owner" };
                return base.ValidatedProperties;
            }
            set
            {
                base.ValidatedProperties = value;
            }
        }

        protected override string GetValidationError(string propertyName)
        {
            if (Array.IndexOf(ValidatedProperties, propertyName) < 0)
                return null;

            string error = null;

            if (propertyName == "ProgramDesc")
                error = ValidateProgramDesc();
            else if (propertyName == "Owner")
                error = ValidateOwner();

            return error;
        }

        string ValidateProgramDesc()
        {
            if (IsStringMissing(this.ProgramDesc))
                return "Program Name required";
            return null;
        }
        string ValidateOwner()
        {
            if (IsStringMissing(this.Owner))
                return "Owner name required";
            return null;
        }

        #endregion
    }
}
