﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDS.Models.Scans.Harness
{
    public class Branch : BaseModel
    {
        public static Branch CreateBranch() => new Branch();
        public static Branch CreateBranch(string branchName, string length, string diameter) => new Branch { BrancheName = branchName, Length = length, Diameter = diameter };

        #region Properties

        public string BrancheName { get; set; }
        public string Length { get; set; }
        public string Diameter { get; set; }

        #endregion

    }
}
