﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDS.Models.Scans.Harness
{
    public class Device : BaseModel
    {
        public static Device CreateDevice() { return new Device(); }
        public static Device CreateDevice(string partNumber, string partName, string deviceType) 
        {
            return new Device
            {
                PartNumber = partNumber,
                PartName = partName,
                DeviceType = deviceType
            };
        }

        #region Properties

        public string PartNumber { get; set; }
        public string PartName{ get; set; }
        public string DeviceType { get; set; }

        #endregion
    }
}
