﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDS.Models.Scans.Harness
{
    public class Bundle : BaseModel
    {
        public static Bundle CreateBundle() => new Bundle();
        public static Bundle CreateBundle(string bundleName) => new Bundle { BundleName = bundleName };

        #region Properties

        public string BundleName { get; set; }

        #endregion
    }
}
