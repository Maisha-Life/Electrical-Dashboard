﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDS.Models
{
    public class Construct : BaseModel
    {
        public static Construct CreateConstruct() { return new Construct() { Id_Construct = "-1" }; }
        public static Construct CreateConstruct(string constructTypeDesc, string constructDesc) => new Construct()
        {
            Id_Construct = "-1",
            ConstructTypeDesc = constructTypeDesc,
            ConstructDesc = constructDesc
        };
        public static Construct CreateConstruct(string id_construct, string constructTypeDesc, string constructDesc) => new Construct()
        {
            Id_Construct = id_construct,
            ConstructTypeDesc = constructTypeDesc,
            ConstructDesc = constructDesc
        };

        #region Properties

        public string Id_Construct { get; set; }
        public string ConstructTypeDesc { get; set; } // Id_ConstructType
        public string ConstructDesc { get; set; }

        #endregion

        #region Validation

        protected override string[] ValidatedProperties
        {
            get
            {
                if (base.ValidatedProperties == null)
                    base.ValidatedProperties = new string[] { "ConstructDesc" };
                return base.ValidatedProperties;
            }
            set
            {
                base.ValidatedProperties = value;
            }
        }

        protected override string GetValidationError(string propertyName)
        {
            if (Array.IndexOf(ValidatedProperties, propertyName) < 0)
                return null;

            string error = null;

            if (propertyName == "ConstructDesc")
                error = this.ValidateDescription();

            return error;
        }

        string ValidateDescription()
        {
            if (IsStringMissing(this.ConstructDesc))
                return "valid string required";
            return null;
        }

        #endregion
    }
}