﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDS.Models
{
    public class RuleConstruct : BaseModel
    {
        public static RuleConstruct CreateRuleConstruct() { return new RuleConstruct() { Id_RuleConstruct = "-1" }; }
        public static RuleConstruct CreateRuleConstruct(string ruleConstructOrder, string methodTypeDesc) => new RuleConstruct()
        {
            Id_RuleConstruct = "-1",
            RuleConstructOrder = ruleConstructOrder,
            MethodTypeDesc = methodTypeDesc
        };
        public static RuleConstruct CreateRuleConstruct(string id_ruleConstruct, string ruleConstructOrder, string methodTypeDesc) => new RuleConstruct()
        {
            Id_RuleConstruct = id_ruleConstruct,
            RuleConstructOrder = ruleConstructOrder,
            MethodTypeDesc = methodTypeDesc
        };

        #region Properties

        public string Id_RuleConstruct { get; set; }

        public string Id_Constant { get; set; }

        public string MethodTypeDesc { get; set; } // Id_MethodType....
        public string RuleConstructOrder { get; set; }

        #endregion        
    }
}
