﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDS.Models
{
    public class RuleConstant : BaseModel
    {
        public static RuleConstant CreateConstant() => new RuleConstant() { Id_RuleConstant = "-1" };

        public static RuleConstant CreateConstant(string id_rule, string id_construct) => new RuleConstant()
        {
            Id_RuleConstant = "-1",
            Id_Rule = id_rule,
            Id_Construct = id_construct
        };
        public static RuleConstant CreateConstant(string id_ruleconstant, string id_rule, string id_construct) => new RuleConstant()
        {
            Id_RuleConstant = id_ruleconstant,
            Id_Rule = id_rule,
            Id_Construct = id_construct
        };

        #region Properties

        public string Id_RuleConstant { get; set; }

        public string Id_Rule { get; set; }
        public string Id_Construct { get; set; }

        #endregion
    }
}
