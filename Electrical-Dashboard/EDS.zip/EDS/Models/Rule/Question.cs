﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDS.Models
{
    public class Question : BaseModel
    {
        public static Question CreateQuestion() => new Question() { Id_Question = "-1", AnswerDesc = "" };
        public static Question CreateQuestion(string questionDesc, string questionTypeDesc) => new Question()
        {
            Id_Question = "-1",
            QuestionDesc = questionDesc,
            AnswerDesc = "",
            QuestionTypeDesc = questionTypeDesc
        };
        public static Question CreateQuestion(string questionDesc, string answerDesc, string questionTypeDesc) => new Question()
        {
            Id_Question = "-1",
            QuestionDesc = questionDesc,
            AnswerDesc = answerDesc,
            QuestionTypeDesc =  questionTypeDesc
        };
        public static Question CreateQuestion(string id_question, string questionDesc, string answerDesc, string questionTypeDesc) => new Question()
        {
            Id_Question = id_question,
            QuestionDesc = questionDesc,
            AnswerDesc = answerDesc,
            QuestionTypeDesc = questionTypeDesc
        };

        #region Properties

        public string Id_Question { get; set; }

        public string QuestionDesc { get; set; }
        public string AnswerDesc { get; set; }

        public string QuestionTypeDesc { get; set; } 

        #endregion
    }
}
