﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDS.Models
{
    public class Group : BaseModel
    {
        public static Group CreateGroup() => new Group() { Id_Group = "-1" };

        public static Group CreateGroup(string id_group, string grouptype, string grouprank, string groupname, string groupdescription) => new Group()
        {
            Id_Group = id_group,
            GroupType = grouptype,
            GroupRank = grouprank,
            GroupName = groupname,
            GroupDescription = groupdescription
        };

        #region Properties

        public string Id_Group { get; set; }
        public string GroupType { get; set; }
        public string GroupRank { get; set; }
        public string GroupName { get; set; }
        public string GroupDescription { get; set; }

        #endregion
    }
}
