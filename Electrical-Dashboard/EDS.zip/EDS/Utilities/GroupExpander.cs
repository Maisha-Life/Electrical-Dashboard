﻿using System.Windows;
using System.Windows.Controls;

namespace MVVM.Utilities
{
    public class GroupExpander : ContentControl
    {
        public string Header
        {
            get { return (string)GetValue(HeaderProperty); }
            set { SetValue(HeaderProperty, value); }
        }
        public static readonly DependencyProperty HeaderProperty =
             DependencyProperty.Register("Header", typeof(string), typeof(GroupExpander),
             new PropertyMetadata(string.Empty));
        static GroupExpander()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(GroupExpander),
              new FrameworkPropertyMetadata(typeof(GroupExpander)));
        }
    }
}
