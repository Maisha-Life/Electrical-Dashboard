﻿using System;
using System.Threading;
using System.Windows.Threading;
using System.Windows;

using EDS.Windows;

namespace EDS.Utilities
{
    internal class ToolBarHelper
    {
        public static EDSToolBar EDSToolBar { get; set; }
        public static bool VisibleBool { get; set; }

        public static void Show()
        {
            if (EDSToolBar != null)
            {
                VisibleBool = true;
                EDSToolBar.Show();
            }
        }

        public static void Close()
        {
            if (EDSToolBar != null)
            {
                VisibleBool = false;
                EDSToolBar.Close();
            }
        }
    }
}
