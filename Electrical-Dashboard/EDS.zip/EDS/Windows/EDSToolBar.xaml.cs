﻿using Microsoft.Win32;
using System.Windows;
using sD = System.Drawing;
using sF = System.Windows.Forms;

using EDS.Utilities;

namespace EDS.Windows
{
    /// <summary>
    /// Interaction logic for EDSToolBar.xaml
    /// </summary>
    public partial class EDSToolBar : Window
    {
        public EDSToolBar()
        {
            ToolBarHelper.EDSToolBar = this;
            DataContext = App.ToolBarVM;

            InitializeComponent();

            tools.DataContext = App.ToolsVM;

            var currentDPI = (int)Registry.GetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop\\WindowMetrics", "AppliedDPI", 96);
            var scale = 96 / (float)currentDPI;

            var posX = sF.Cursor.Position.X;
            var posY = sF.Cursor.Position.Y;
            sF.Screen selectedScreen = sF.Screen.FromPoint(new sD.Point(posX, posY));

            this.Top = selectedScreen.Bounds.Top * scale;
            this.Left = (selectedScreen.Bounds.Left + ((selectedScreen.Bounds.Right - selectedScreen.Bounds.Left) / 2 - (this.Width / 2))) * scale;
        }
    }
}
