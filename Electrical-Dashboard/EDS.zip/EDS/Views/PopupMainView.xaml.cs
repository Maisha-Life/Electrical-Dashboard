﻿using System.Windows.Controls;

using EDS.Utilities;
using EDS.ViewModels.ViewsVM;

namespace EDS.Views
{
    /// <summary>
    /// Interaction logic for PopupMainView.xaml
    /// </summary>
    public partial class PopupMainView : UserControl
    {
        PopupVM mpvm = new PopupVM();

        public PopupMainView()
        {
            PopupHelper.PopupView = this;
            InitializeComponent();
            DataContext = mpvm;
        }
    }
}
