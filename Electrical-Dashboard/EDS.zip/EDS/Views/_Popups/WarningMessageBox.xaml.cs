﻿using System.Windows;
using System.Windows.Forms;

namespace EDS.Views.Popups
{
    /// <summary>
    /// Interaction logic for WarningMessageBox.xaml
    /// </summary>
    public partial class WarningMessageBox : Window
    {
        public WarningMessageBox()
        {
            InitializeComponent();
        }

        static WarningMessageBox MsgBox;
        static DialogResult result;
        
        public static DialogResult ShowBox(string target, string parent)
        {
            MsgBox = new WarningMessageBox();

            MsgBox.tbTarget.Text = target;
            MsgBox.tbParent.Text = parent;

            MsgBox.ShowDialog();

            return result;
        }

        private void Close_Window(object sender, RoutedEventArgs e)
        {
            result = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void Confirm_Window(object sender, RoutedEventArgs e)
        {
            result = System.Windows.Forms.DialogResult.Yes;
            this.Close();
        }
    }
}
