﻿using System.Windows;
using System.Windows.Controls;

using EDS.Utilities;


namespace EDS.Views
{
    /// <summary>
    /// Interaction logic for MainView.xaml
    /// </summary>
    public partial class MainView : UserControl
    {
        public MainView()
        {
            DataContext = App.MainVM;

            InitializeComponent();

            activeTools.DataContext = App.ProgramsVM.EDSData;
        }
    }
}
