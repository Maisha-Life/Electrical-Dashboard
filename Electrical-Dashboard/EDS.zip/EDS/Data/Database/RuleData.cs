﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows;
using EDS.Models;
using EDS.ViewModels.ModelsVM;

namespace EDS.Data
{
    public class RuleData
    {
        public RuleData() { }

        #region Properties

        private string query;

        private ObservableCollection<vmRuleBase> _RuleList;
        public ObservableCollection<vmRuleBase> RuleList
        {
            get { return _RuleList ?? (_RuleList = new ObservableCollection<vmRuleBase>()); }
            set { _RuleList = value; }
        }
        //parameter and harness filter by type
        private ObservableCollection<vmConstructBase> _ParametersList;
        public ObservableCollection<vmConstructBase> ParametersList
        {
            get { return _ParametersList ?? (_ParametersList = new ObservableCollection<vmConstructBase>()); }
            set { _ParametersList = value; }
        }
        private ObservableCollection<vmGroup> _GroupsList;
        public ObservableCollection<vmGroup> GroupsList
        {
            get { return _GroupsList ?? (_GroupsList = new ObservableCollection<vmGroup>()); }
            set { _GroupsList = value; }
        }

        private ObservableCollection<vmConstructBase> _ConstraintList;
        public ObservableCollection<vmConstructBase> ConstraintList
        {
            get { return _ConstraintList ?? (_ConstraintList = new ObservableCollection<vmConstructBase>()); }
            set { _ParametersList = value; }
        }

        private ObservableCollection<vmConstructBase> _LogicList;
        public ObservableCollection<vmConstructBase> LogicList
        {
            get { return _LogicList ?? (_LogicList = new ObservableCollection<vmConstructBase>()); }
            set { _LogicList = value; }
        }
        

        #endregion

        #region Methods

        public void grabData()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(App.connString))
                {
                    con.Open();
                    grabDatabaseInfo(con);
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void grabDatabaseInfo(SqlConnection con)
        {
            RuleList.Clear();

            ParametersList.Clear();
            GroupsList.Clear();
            ConstraintList.Clear();
            LogicList.Clear();

            populateConstructs(con);
            populateGroups(con);

            grabRule(con);
        }

        private void populateConstructs(SqlConnection con)
        {
            string type;

            query = "select c.Id_Construct, t.TypeDesc, c.ConstructDesc  " +
                    "from ([Constructs] c inner join [Types] t on c.Id_ConstructType = t.Id_Type)";

            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                type = reader[1].ToString();

                if (type == "Parameter")
                    ParametersList.Add(new vmParameter(Construct.CreateConstruct(reader[0].ToString(), type, reader[2].ToString()), ParametersList));
                else if (type == "Constraint")
                    ConstraintList.Add(new vmConstructBase(Construct.CreateConstruct(reader[0].ToString(), type, reader[2].ToString()), ConstraintList));
                else if (type == "Logic")
                    LogicList.Add(new vmConstructBase(Construct.CreateConstruct(reader[0].ToString(), type, reader[2].ToString()), LogicList));
            }

            reader.Close();

            command.Dispose();
        }

        private void populateGroups(SqlConnection con)
        {
            string type;

            query = "select g.Id_Group, t.TypeDesc, g.Rank, g.Name, g.Description  " +
                    "from ([Groups] g inner join [Types] t on g.Id_GroupType = t.Id_Type)";

            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                type = reader[1].ToString();

                GroupsList.Add(new vmGroup(Group.CreateGroup(reader[0].ToString(), type, reader[2].ToString(), reader[3].ToString(), reader[4].ToString())));
            }

            reader.Close();

            command.Dispose();
        }
        private void grabRule(SqlConnection con)
        {
            query = "select r.Id_Rule, t.TypeDesc, r.DesignRule,r.RuleName, r.RuleDesc, r.Id_Status, r.ConstraintBool, r.CheckBool, r.RepairBool, t2.TypeDesc, t3.TypeDesc, r.Author " +
                    "from ((([Rules] r inner join [Types] t on r.Id_RuleType = t.Id_Type) inner join [Types] t2 on r.Id_CheckType = t2.Id_Type) inner join [Types] t3 on r.Id_RepairType = t3.Id_Type)";

            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                vmRuleAll rule = new vmRuleAll(Rule.CreateRule(reader[0].ToString(), reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), 
                                                               reader[4].ToString(), Convert.ToInt32(reader[5]), (bool)reader[6], (bool)reader[7], 
                                                               (bool)reader[8], reader[9].ToString(), reader[10].ToString(), reader[11].ToString()),RuleList, false);

                checkLegacyID(con, rule);

                grabRuleQuestion(con, rule);
                grabConstants(con, rule);
                grabCategories(con, rule);

                RuleList.Add(rule);
            }

            reader.Close();

            command.Dispose();
        }

        private void checkLegacyID(SqlConnection con, vmRuleAll rule)
        {
            query = "select LegacyIDDesc from LegacyID where Id_Rule = " + rule._rule.Id_Rule;

            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
                rule._rule.LegacyIDDesc = reader[0].ToString();

            command.Dispose();
        }
        private void grabRuleQuestion(SqlConnection con, vmRuleAll rule)
        {
            query = "select q.Id_Question, q.QuestionDesc, q.AnswerDesc, t.TypeDesc " +
                    "from ([Questions] q inner join [Types] t on q.Id_QuestionType = t.Id_Type) " +
                    "where Id_Rule = " + rule._rule.Id_Rule;

            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
                rule.questions.Add(new vmQuestion(Question.CreateQuestion(reader[0].ToString(), reader[1].ToString(), reader[2].ToString(), reader[3].ToString()), rule.questions, rule));

            reader.Close();

            rule.QuestionBool = rule.CheckQuestionsStatus();

            command.Dispose();
        }
        private void grabConstants(SqlConnection con, vmRuleAll rule)
        {
            populateParameters(rule);

            query = "select c.Id_RuleConstant, c.Id_Construct, t.TypeDesc, cs.ConstructDesc" +
                    " from (([RuleConstants] c inner join [Constructs] cs on c.Id_Construct = cs.Id_Construct)" +
                    " inner join [Types] t on cs.Id_ConstructType = t.Id_Type) where c.Id_Rule = " + rule._rule.Id_Rule;

            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                string id_construct = reader[1].ToString();
                foreach (vmConstructBase constant in rule.constants)
                    if (id_construct == constant._construct.Id_Construct)
                    {
                        (constant as vmParameter).selectedBool = true;
                        grabConstructs(con, rule, constant, reader[0].ToString(), reader[2].ToString());
                        goto Finish;
                    }

                //if not at Finish means it is a Constraint that is related to the given rule
                vmRuleConstraint constraint = new vmRuleConstraint(Construct.CreateConstruct(reader[1].ToString(), reader[2].ToString(), reader[3].ToString()), rule.constraints, rule);

                rule.constraints.Add(constraint);

                grabConstructs(con, rule, constraint, reader[0].ToString(), reader[2].ToString());
            Finish:
                continue;
            }

            reader.Close();

            command.Dispose();
        }
        //need to update and grab the construct type as well...
        private void grabConstructs(SqlConnection con, vmRuleAll rule, vmConstructBase baseConstruct, string id_constant, string type)
        {
            query = "select rc.Id_RuleConstruct, rc.ConstructOrder, t.TypeDesc   " +
                    "from ([RuleConstructs] rc inner join [Types] t on rc.Id_MethodType = t.Id_Type) " +
                    "where Id_RuleConstant = " + id_constant;

            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                vmRuleConstruct construct = null;

                if (reader[2].ToString().Contains("Check"))
                {
                    if (type == "Parameter")
                        construct = new vmRuleConstruct(RuleConstruct.CreateRuleConstruct(reader[0].ToString(), reader[1].ToString(), reader[2].ToString()), rule._checkConstructs, ParametersList, rule);
                    else if (type == "Constraint")
                        construct = new vmRuleConstruct(RuleConstruct.CreateRuleConstruct(reader[0].ToString(), reader[1].ToString(), reader[2].ToString()), rule._checkConstructs, rule.constraints, rule);
                    else
                        construct = new vmRuleConstruct(RuleConstruct.CreateRuleConstruct(reader[0].ToString(), reader[1].ToString(), reader[2].ToString()), rule._checkConstructs, LogicList, rule);

                    construct.setDefaultConstruct(baseConstruct);
                    rule._checkConstructs.Add(construct);
                }
                else
                {
                    if (type == "Parameter")
                        construct = new vmRuleConstruct(RuleConstruct.CreateRuleConstruct(reader[0].ToString(), reader[1].ToString(), reader[2].ToString()), rule._repairConstructs, ParametersList, rule);
                    else if (type == "Constraint")
                        construct = new vmRuleConstruct(RuleConstruct.CreateRuleConstruct(reader[0].ToString(), reader[1].ToString(), reader[2].ToString()), rule._repairConstructs, rule.constraints, rule);
                    else
                        construct = new vmRuleConstruct(RuleConstruct.CreateRuleConstruct(reader[0].ToString(), reader[1].ToString(), reader[2].ToString()), rule._repairConstructs, LogicList, rule);

                    construct.setDefaultConstruct(baseConstruct);
                    rule._repairConstructs.Add(construct);
                }
            }

            reader.Close();

            command.Dispose();
        }
        private void grabCategories(SqlConnection con, vmRuleAll rule)
        {
            query = "select c.Id_RuleGroup from [RuleCategory] c where c.Id_Rule =" + rule._rule.Id_Rule;

            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                string id_group = reader[0].ToString();
                foreach (vmGroup group in rule.groups)
                    if (id_group == group._group.Id_Group)
                    {
                        (group as vmGroup).selectedBool = true;
                        goto Finish;
                    }

                Finish:
                continue;
            }

            reader.Close();

            command.Dispose();
        }

            public void populateParameters(vmRuleAll rule)
        {
            foreach (vmConstructBase constraint in ParametersList)
                rule.constants.Add(new vmParameter(Construct.CreateConstruct(constraint._construct.Id_Construct, constraint.ConstructTypeDesc, constraint.ConstructDesc), rule.constants, rule, false));

            foreach (vmConstructBase constraint in LogicList)
                rule.constants.Add(new vmParameter(Construct.CreateConstruct(constraint._construct.Id_Construct, constraint.ConstructTypeDesc, constraint._construct.ConstructDesc), rule.constants, rule, false));

            foreach (vmGroup group in GroupsList)
                rule.groups.Add(new vmGroup(Group.CreateGroup(group._group.Id_Group, group._group.GroupType, group._group.GroupRank, group._group.GroupName, group._group.GroupDescription), rule, false));
        }
        #endregion
    }
}