﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows;

using EDS.Models;
using EDS.ViewModels.ModelsVM;

namespace EDS.Data
{
    public class ScanData
    {
        //public string connString = @"Provider=Microsoft.ACE.Sql.12.0;Data Source='C:\Users\" + Environment.UserName + @"\Documents\Github\EDS\Database\EDSDatabase.accdb'";

        public static string rootLoc = @"\\ecc9000105\proj\EESE_MCAD_CORE\Libraries\06_EDS";

        public ScanData() { }

        #region Data

        private ObservableCollection<vmProgram> _programs;
        public ObservableCollection<vmProgram> programs
        {
            get
            {
                if (_programs == null)
                    _programs = new ObservableCollection<vmProgram>();
                return _programs;
            }
            set { if (this._programs != value) this._programs = value; }
        }

        private ObservableCollection<vmTool> _tools;
        public ObservableCollection<vmTool> tools
        {
            get
            {
                if (_tools == null)
                    _tools = new ObservableCollection<vmTool>();
                return _tools;
            }
            set { if (this._tools != value) this._tools = value; }
        }

        #endregion

        #region Methods

        public void grabData()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(App.connString))
                {
                    con.Open();
                    grabDatabaseInfo(con);
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //
        //******************have two tasks here to grab programs and tools...maybe more for each subcomponent of tool
        //

        private void grabDatabaseInfo(SqlConnection con)
        {
            programs.Clear();
            tools.Clear();

            grabProgramInfo(con);
            grabToolsInfo(con);
        }

        private void grabProgramInfo(SqlConnection con)
        {
            string query = "select p.Id_Program, p.ProgramDesc, u.UserDesc from " +
                           "([Programs] p inner join [Users] u on p.Id_User = u.Id_User)";

            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                vmProgram newProgram = new vmProgram(Program.CreateProgram(reader[0].ToString(), reader[1].ToString(), reader[2].ToString()), _programs);

                grabHarnessInfo(con, newProgram._program.Id_Program, ref newProgram);

                _programs.Add(newProgram);
            }

            reader.Close();
        }
        private void grabHarnessInfo(SqlConnection con, string programID, ref vmProgram newProgram)
        {

            string query = "select h.Id_Harness, h.Id_HarnessGroup, hg.HarnessDesc, h.Revision, u.UserDesc, h.ToolsScanBool, h.PMIBool, h.DTSyncBool, h.FFA2Bool, h.RenamingBool, h.HarnessCheckBool from " +
                           "(([Harnesses] h inner join [Users] u on h.Id_User = u.Id_User)" +
                           " inner join [HarnessGroup] hg on h.Id_HarnessGroup = hg.Id_HarnessGroup)" +
                           "where hg.Id_Program=" + programID;

            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                vmHarness newHarness = new vmHarness(Harness.CreateHarness(reader[0].ToString(), reader[1].ToString(), reader[2].ToString(), programID, reader[3].ToString(),
                                                                           reader[4].ToString(), (bool)reader[5], (bool)reader[6], (bool)reader[7], (bool)reader[8], (bool)reader[9],
                                                                           (bool)reader[10]), newProgram.Harnesses, newProgram);

                grabCheckResultsInfo(con, newHarness._harness.Id_Harness, ref newHarness);
                
                newProgram.Harnesses.Add(newHarness);
            }

            reader.Close();
        }
        private void grabCheckResultsInfo(SqlConnection con, string harnessID, ref vmHarness newHarness)
        {
            //string query = "select cr.CheckResultDesc, cr.Id_Rulez, ls.LevelDesc " +
            //               "from ([CheckResults] cr inner join [Levels] ls on cr.Id_Level = ls.Id_Level) " +
            //               "where Id_Harness = " + harnessID;

            //SqlCommand command = new SqlCommand(query, con);
            //SqlDataReader reader = command.ExecuteReader();

            //while (reader.Read())
            //{
            //    vmHarnessCheckResult newCheck = new vmHarnessCheckResult(Check.CreateCheck(reader[0].ToString(), reader[1].ToString(), harnessID ,reader[2].ToString()));

            //    newHarness.addToRule(newCheck);
            //}

            //reader.Close();
        }       

        private void grabToolsInfo(SqlConnection con)
        {
            string query = "select t.Id_Tool, t.ToolName, t.ToolShortName, t.ToolExe, t.ToolImage, t.ToolDesc from [Tools] t";

            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                vmTool newTool = new vmTool(reader[1].ToString(),reader[2].ToString(), rootLoc + reader[3].ToString(), "exe", 
                                            rootLoc + reader[4].ToString(), reader[5].ToString(), grabProcessNames(con, reader[0].ToString()));

                _tools.Add(newTool);
            }

            reader.Close();
        }
        private List<string> grabProcessNames(SqlConnection con, string toolID)
        {
            List<string> processList = new List<string>();

            string query = "select pn.ToolProcessNameDesc from [ToolProcessNames] pn where pn.Id_Tool = " + toolID;

            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read()) processList.Add(reader[0].ToString());

            return processList;
        }

        private bool returnBool(string value)
        {
            return (value == "1" ? true : false);
        }

        #endregion
    }
}
