﻿using System;
using sw = System.Windows;
using System.Windows.Forms;
using System.Xml.Linq;

using EDS.Models.Scans.Harness;
using EDS.ViewModels.ModelsVM.Scans.Harness;

//Class developed by: EDS Core Development FNA/FOM -2017
//Harzagan/jmill592/rariashe/ayu12
//Ford Motor Company
//DO NOT ERASE -  PROPERTY OF EDS CORE/MCAD - FNA/FoM

namespace EDS.Data
{
    public class XMLHarness : BaseHarness
    {
        private XDocument xmlDoc;

        public XMLHarness()
        {
            checkXML();
        }

        public void checkXML()
        {
            string fileName = "";

            using (var fbd = new OpenFileDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.FileName))
                {
                    fileName = fbd.FileName;
                    try                 // open file
                    {
                        xmlDoc = XDocument.Load(fileName);
                        name = xmlDoc.Root.LastAttribute.PreviousAttribute.Value;
                        connection = true;
                    }
                    catch (Exception)
                    {
                        connection = false;
                        sw.MessageBox.Show("Invalid File");
                        return;
                    }
                }
                else
                    sw.MessageBox.Show("Please select a file.");
            }
        }

        public override void grabData()
        {
            foreach (XElement element in xmlDoc.Root.Elements())
            {
                if (element.FirstAttribute.Value == "Branch")
                {
                    foreach (XElement branch in element.Elements())
                        if (branch.LastAttribute.Name == "value")
                        {
                             addBranchToBundle(Branch.CreateBranch(branch.Attribute("value").Value,
                                                                   element.Attribute("length").Value,
                                                                   element.Attribute("diameter").Value),
                                                                   branch.Attribute("value").Value);
                            break;
                        }
                }
                else if (element.FirstAttribute.Value == "Device")
                    devices.Add(new vmDevice(Device.CreateDevice(element.Attribute("compType").Value, element.Attribute("name").Value, "Device"), devices));

                else if (element.FirstAttribute.Value == "Fixing")
                    devices.Add(new vmDevice(Device.CreateDevice(element.Attribute("compType").Value, element.Attribute("name").Value, "Fixing"), devices));
            }
        }
        private void addBranchToBundle(Branch branch, string bundleName)
        {
            foreach (vmBundle bundle in bundles)
                if (bundle.BundleName == bundleName)
                {
                    bundle.Branches.Add(new vmBranch(branch, bundle.Branches));
                    return;
                }

            vmBundle newBundle = new vmBundle(Bundle.CreateBundle(bundleName), bundles);
            newBundle.Branches.Add(new vmBranch(branch, newBundle.Branches));

            bundles.Add(newBundle);
        }
    }
}