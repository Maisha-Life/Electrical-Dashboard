﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using EDS.ViewModels.ModelsVM.Scans.Harness;

namespace EDS.Data
{
    public class BaseHarness
    {
        public bool connection;
        public static string name;

        public ObservableCollection<vmBundle> bundles = new ObservableCollection<vmBundle>();
        public ObservableCollection<vmDevice> devices = new ObservableCollection<vmDevice>();

        public virtual void grabData() {}
    }
}
