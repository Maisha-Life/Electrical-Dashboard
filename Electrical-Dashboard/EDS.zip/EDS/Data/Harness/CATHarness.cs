﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using sw = System.Windows;

//using INFITF;
//using KnowledgewareTypeLib;
//using ProductStructureTypeLib;

using MVVM.Utilities;

using EDS.ViewModels.ModelsVM.Scans.Harness;
using EDS.Models.Scans.Harness;

//Class developed by: EDS Core Development FNA/FOM -2017
//Harzagan/jmill592/rariashe/ayu12
//Ford Motor Company
//DO NOT ERASE -  PROPERTY OF EDS CORE/MCAD - FNA/FoM

//--------------------------------------------------------------------------------//

//Function developed by: EDS Core Development FNA/FOM -2017
//Harzagan/jmill592/rariashe/ayu12
//Ford Motor Company
//DO NOT ERASE -  PROPERTY OF EDS CORE/MCAD - FNA/FoM

namespace EDS.Data
{
    public class CATHarness : BaseHarness
    {
        //static CatiaLink catiaLink;
        //static INFITF.Application catia;

        //static Document activeDocument;
        //static ProductDocument prodDoc;

        //public CATHarness()
        //{
        //    //check connection and grab name
        //    connection = checkConnection();
        //}

        //#region Grab Data

        //public override void grabData()
        //{
        //    if (checkConnection())
        //        selectElectrical();
        //}

        //private void selectElectrical()
        //{
        //    #region variables

        //    int selCount;
        //    string type;

        //    Selection sel = activeDocument.Selection;
        //    SelectedElement selElement;

        //    Product selProd;

        //    Queue<SelectedElement> searchArray = new Queue<SelectedElement>();

        //    #endregion

        //    sel.Clear();

        //    sel.Search("((((('Assembly Design'.Part)-'Assembly Design'.Part.'Name In Graph'=*EXTSPL*)+ Electrical.'Single Insert Connector'))), all");
        //    selCount = sel.Count;

        //    for (int i = 1; i <= selCount; i++)
        //        searchArray.Enqueue(sel.Item2(i));

        //    while (searchArray.Count > 0)
        //    {
        //        selElement = searchArray.Dequeue();

        //        selProd = (Product)selElement.LeafProduct;

        //        type = getType(selProd);

        //        if (type == "B")
        //            grabBundleProperties(selProd);
        //        else
        //            grabDeviceProperties(selProd, type);
        //    }
        //}

        //private void grabBundleProperties(Product selProd)
        //{
        //    #region variables

        //    string[] delim = new string[] { @"\" };
        //    string branchDiameter = "";
        //    int branchCount = 0;

        //    Parameters objParams = selProd.Parameters;

        //    #endregion

        //    vmBundle bundle = new vmBundle(Bundle.CreateBundle(selProd.get_Name()), bundles);

        //    for (int i = 1; i <= objParams.Count; i++)
        //    {
        //        Parameter objParam = objParams.Item(i);

        //        if (objParam.get_Name().Contains(@"\Constraints") && objParam.get_Name().Contains(@"\Diameter"))
        //            branchDiameter = objParam.ValueAsString().TrimEnd('m');
        //        else if (objParam.get_Name().Contains(@"\Constraints") && objParam.get_Name().Contains(@"\Length"))
        //        {
        //            branchCount++;
        //            string[] objName = objParam.get_Name().Split(delim, StringSplitOptions.RemoveEmptyEntries);

        //            bundle.Branches.Add(new vmBranch(Branch.CreateBranch(objName[2],objParam.ValueAsString().TrimEnd('m'),branchDiameter), bundle.Branches));
        //        }
        //    }

        //    bundles.Add(bundle);
        //}
        //private void grabDeviceProperties(Product selProd, string type)
        //{
        //    if (selProd.get_Name().Contains("TKO"))
        //        goto skipcomponent;
        //    devices.Add(new vmDevice(Device.CreateDevice(selProd.get_PartNumber(), selProd.get_Name(), type),devices));
        //skipcomponent: ;
        //}

        //private string getType(Product checkPart)
        //{
        //    Regex clipRegExp = new Regex("i*EHISUPPORT"); //Retainer
        //    Regex connectorRegExp = new Regex("i*(CnctPt)");
        //    Regex bundleRegExp = new Regex("i*ElecLogTerm");

        //    Publications checkPub = checkPart.Publications;

        //    if (checkPart.get_Nomenclature().Contains("PIA") || checkPart.get_Definition().Contains("PIA"))
        //        return "PIA";
        //    else if (checkPub.Count < 1)
        //        return "Mechanical";

        //    for (int i = 1; i <= checkPub.Count; i++)
        //    {
        //        string pubName = checkPub.Item(i).get_Name();
        //        //BUNDLE
        //        if (bundleRegExp.IsMatch(checkPub.Item(i).get_Name()) == true)
        //            return "B";
        //        //RETAINER
        //        else if (clipRegExp.IsMatch(checkPub.Item(i).get_Name()) == true)
        //            return "Retainer";
        //        //CONNECTOR
        //        else if (connectorRegExp.IsMatch(pubName) == true)
        //            return "Connector";
        //    }
        //    //if nothing set then do this
        //    return "Unknown";
        //}

        //#endregion

        //#region CATIA connection

        //private static bool checkConnection()
        //{
        //    bool connectionBool = true;

        //    if (catiaLink == null)
        //        catiaLink = new CatiaLink();

        //    if (connectCatia())
        //    {
        //        connectionBool = true;
        //        selectTopLevel();
        //    }
        //    else
        //        connectionBool = false;

        //    return connectionBool;
        //}
        //private static bool connectCatia()
        //{
        //    //if no connectino to CATIA, dont exit program, just dont carry on with function
        //    catia = catiaLink.CATIA;

        //    if (catia == null)
        //        return false;

        //    //check activedocument
        //    try
        //    {
        //        activeDocument = catia.ActiveDocument;
        //        return true;
        //    }
        //    catch
        //    {
        //        sw.MessageBox.Show("Could not connect to the Active Document. Please check the Active Document in CATIA");
        //        return false;
        //    }
        //}
        //private static void selectTopLevel()
        //{
        //    Selection sel = activeDocument.Selection;

        //    try
        //    {
        //        prodDoc = (ProductDocument)activeDocument;
        //        Products prods = prodDoc.Product.Products;
        //        name = prodDoc.Product.get_Name();
        //        sel.Clear();
        //        sel.Add((AnyObject)prods);
        //    }
        //    catch
        //    {
        //        sw.MessageBox.Show("You have selected a Part Document, you need to select a Product Document PLEASE RESTART THE TOOL");
        //    }

        //    catia.RefreshDisplay = true;
        //    catia.StartCommand("FrmActivate");
        //}

        //#endregion

        //#region Methods

        //public void ReframeOn(string selObj)
        //{
        //    checkConnection();

        //    Selection sel = activeDocument.Selection;
        //    string search = "Name='" + selObj + "',all";
        //    sel.Search(search);
        //    if (sel.Count != 0)
        //    {
        //        catia.StartCommand("Center Graph");
        //        catia.StartCommand("Reframe On");
        //    }
        //}

        //public static string GrabProductDescription()
        //{
        //    checkConnection();

        //    return prodDoc.Product.get_DescriptionRef();
        //}

        //#endregion
    }
}