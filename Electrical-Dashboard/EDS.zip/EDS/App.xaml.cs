﻿using Microsoft.Shell;

using System;
using System.Collections.Generic;
using System.Windows;

using EDS.ViewModels.ViewsVM;

namespace EDS
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : ISingleInstanceApp
    {
        private const string Unique = "EDS";
        public static string connString = @"Data Source=(LocalDb)\MSSQLLocalDB;Initial Catalog=RulezDatabase;Integrated Security=True;MultipleActiveResultSets=true";
        //public static string connString = @"Data Source=WGC1107M041N2\SQLEXPRESS;Initial Catalog = RulezDatabase2; Integrated Security = True;MultipleActiveResultSets=true";
        //public static string connString = @"Data Source=ito070623.hosts.cloud.ford.com; Initial Catalog=EDDatabase;Integrated Security = True;MultipleActiveResultSets=true";

        public static string[] explanationQuestions = new string[]
        {
            "Why does the consideration exist?",
            "What happens if you deviate (failure mode)?",
            "Is the consideration an industry standard?",
            "What types of things prevent you from meeting this consideration?",
            "What are the constraints?",
            "What are the trade offs?",
            "At what point do you absolutely not want to go below?",
            "At what point is the cost benefit ratio too high?",
            "If you do deviate what might be the consequence in the future?"
        };
        public static string[] analysisQuestions = new string[]
        {
            "What is the suggested analytical process to verify consideration?",
            "What is the evidence for the consideration?",
            "Is there a suggested process to get that evidence?",
            "Give the exact title of the program, document or calculation?",
            "If you do not meet the consideration after the initial analysis, what design changes are suggested to bring the design closer or to meet the considerations?",
            "Is there related DV test/requirement associated with this consideration?"
        };
        public static string[] discussionQuestions = new string[]
        {
            "If you have to deviate are there any design changes to compensate that will help the system be more robust?",
            "What additional analysis or testing needs to be done to have confidence in the design?",
            "What change in the program/current model update would require this rule to be assessed/analyzed?",
            "Does it only apply to new design?",
            "When in the program do you do this?",
            "Identify task number in step guide:",
            " Identify which interfacing activities are involved:"
        };

        private static RuleVM _RuleVM;
        public static RuleVM RuleVM
        {
            get { return _RuleVM ?? (_RuleVM = new RuleVM()); }
        }

        private static PopupVM _PopupVM;
        public static PopupVM PopupVM
        {
            get
            {
                if (_PopupVM == null)
                    _PopupVM = new PopupVM();
                return _PopupVM;
            }
        }

        private static vmQuery _MainQuery;
        public static vmQuery MainQuery
        {
            get { return _MainQuery ?? (_MainQuery = new vmQuery()); }
        }

        private static MainVM _MainVM;
        public static MainVM MainVM
        {
            get
            {
                if (_MainVM == null)
                    _MainVM = new MainVM();
                return _MainVM;
            }
        }

        private static ProgramsVM _ProgramsVM;
        public static ProgramsVM ProgramsVM
        {
            get
            {
                if (_ProgramsVM == null)
                    _ProgramsVM = new ProgramsVM();
                return _ProgramsVM;
            }
        }

        private static HarnessScanVM _HarnessScanVM;
        public static HarnessScanVM HarnessScanVM
        {
            get
            {
                if (_HarnessScanVM == null)
                    _HarnessScanVM = new HarnessScanVM();
                return _HarnessScanVM;
            }
        }

        private static ToolsVM _ToolsVM;
        public static ToolsVM ToolsVM
        {
            get
            {
                if (_ToolsVM == null)
                    _ToolsVM = new ToolsVM();
                return _ToolsVM;
            }
        }

        private static ToolBarVM _ToolBarVM;
        public static ToolBarVM ToolBarVM
        {
            get
            {
                if (_ToolBarVM == null)
                    _ToolBarVM = new ToolBarVM();
                return _ToolBarVM;
            }
        }

        [STAThread]
        public static void Main()
        {
            if (SingleInstance<App>.InitializeAsFirstInstance(Unique))
            {
                var application = new App();

                application.InitializeComponent();

                application.Run();

                // Allow single instance code to perform cleanup operations
                SingleInstance<App>.Cleanup();
            }
        }

        public bool SignalExternalCommandLineArgs(IList<string> args)
        {
            return true;
        }

        private void Application_Exit(object sender, ExitEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }
    }
}
